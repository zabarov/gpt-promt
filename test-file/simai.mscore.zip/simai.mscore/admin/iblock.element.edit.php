<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");

global $USER;
global $APPLICATION;


require "include/getprops.php";

\Bitrix\Main\Loader::includeSharewareModule(SF_SOLUTION);
\Bitrix\Main\Loader::includeSharewareModule("iblock");
\Bitrix\Main\Loader::includeSharewareModule("fileman");
\Bitrix\Main\Loader::includeSharewareModule('simai.property');

use \SIMAI\Main\Configuration\Property;
use \SIMAI\Main\Configuration\Site;
use Bitrix\Main\Page\Asset;
use Bitrix\Main\Localization\Loc; 

use \SIMAI\Main\Subsite\Verification;

if(!Verification::Check()) die();

//if(\SIMAI\Main\Subsite\Verification::Check()):




Asset::getInstance()->addCss('/simai/asset/sf-panel/css/style.css');
Asset::getInstance()->addJs( '/simai/asset/sf-panel/js/script.js');


$APPLICATION->ShowHead();

?>
 <style>
  .sf-modal-overlay{
	  z-index: 900 !important;
  }
 </style>
<?

      $settings = \SIMAI\Main\Subsite\Coordinate::GetCashe(str_replace(array("www.",".".SITE_SERVER_NAME), "", $_SERVER["SERVER_NAME"]));

      $organizationID = \SIMAI\Main\Configuration\Property::getValue(SF_SITE_DIR, "id");
      $valueElement=array();
 	  $resIblock = \CIBlock::GetByID($_REQUEST["iblock"]);
	
	  if($arIblock = $resIblock->Fetch()):
	     $fileConfig = $_SERVER["DOCUMENT_ROOT"].SF_DATA_DIR.'/config/.iblock.config.php';
		 
		 $codeIblock= str_replace($arIblock["IBLOCK_TYPE_ID"]."-","",$arIblock["CODE"]);
	     $ROOT_SECTION = \SIMAI\Main\Configuration\Property::getValue(SF_SITE_DIR, $codeIblock);
	  endif;
	 
      if(file_exists($fileConfig)) 
	   $arConfig = require $fileConfig;
   
   
      $iblockLink = array();
	  if(intval($organizationID)){
		  
		  $res = CIBlockElement::GetByID($organizationID);
		  if($ar_res = $res->GetNext()){
			  
			  //по инфоблоку получить коды привязок

			    $properties = CIBlockProperty::GetList(Array("sort" => "asc", "name" => "asc"), Array("ACTIVE"=>"Y", "IBLOCK_ID" => $ar_res["IBLOCK_ID"], "PROPERTY_TYPE" => "G"));
				while ($prop_fields = $properties->GetNext())
				{
				  $iblockLink[$prop_fields["LINK_IBLOCK_ID"]] = strtolower($prop_fields["CODE"]);
				}
		  }
	  }

	   
	   
	   
	   $codeIblock = strtolower($arIblock["CODE"]);
       $pattern = '/[^-]{1,}-/i';
       $replacement = '';
       $cleanCodeIblock =  preg_replace($pattern, $replacement, $codeIblock);
	   
	   
       $arConfig = $arConfig[$arIblock["CODE"]];
	  
	   $res = CIBlock::GetList(Array(),Array('TYPE' => $arIblock["IBLOCK_TYPE_ID"]));
	   $arIblockID=array();
	   while($ar_res = $res->Fetch()){
		  
			$arIblockID[$ar_res['ID']] = $ar_res['CODE'];
		}
		//getfields
		
		$arResult["FIELDS"] = CIBlock::GetFields($_REQUEST["iblock"]);
	  

	   if(isset($_REQUEST["id"])):
	   
		$arSelect = Array("*");
		$arFilter = Array("IBLOCK_ID" => $_REQUEST["iblock"], "ID" => $_REQUEST["id"]);
		$res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
		if($ob = $res->GetNextElement()){ 
		
		   $arFields = $ob->GetFields();  
		   $valueElement = $arFields;
		   $arProps = $ob->GetProperties();
		   $valueElement["PROPERTIES"] = $arProps;
		  
		}
		
		 $valueElement["~IBLOCK_SECTION_ID"] = array();
		 $db_old_groups = CIBlockElement::GetElementGroups($_REQUEST["id"], true);
		 while($ar_group = $db_old_groups->Fetch())
           $valueElement["~IBLOCK_SECTION_ID"][] = $ar_group["ID"];
	  
		endif;
 		

	
	$arProperties=array();
	$properties = CIBlockProperty::GetList(Array("sort"=>"asc", "name"=>"asc"), Array("ACTIVE"=>"Y", "IBLOCK_ID" => $_REQUEST["iblock"]));
	while ($prop_fields = $properties->GetNext())
	{

	   if($prop_fields["PROPERTY_TYPE"]=="L"){
		   
		    $prop_fields["ENUM"] = array();
		    $property_enums = CIBlockPropertyEnum::GetList(Array("DEF"=>"DESC", "SORT"=>"ASC"), Array("IBLOCK_ID"=>$prop_fields["IBLOCK_ID"], "CODE"=>$prop_fields["CODE"]));
			while($enum_fields = $property_enums->GetNext())
			{
			  $prop_fields["ENUM"][$enum_fields["ID"]] = $enum_fields["~VALUE"];
			} 
	   }elseif($prop_fields["USER_TYPE"]=="simai_ib_element" || $prop_fields["PROPERTY_TYPE"]=="E"){
		   
		    $prop_fields["ENUM"] = array();
			
			if($prop_fields["USER_TYPE"]=="simai_ib_element"){
				//получить по коду инфоблока ид инфоблока
				$res = CIBlock::GetList(array(),array("CODE"=> $prop_fields['USER_TYPE_SETTINGS']['LINK_IBLOCK_CODE']), false);
				if($ar_res = $res->Fetch())
				{
					$lIblockID = $ar_res['ID'];
				}
			}else{
				$lIblockID = $prop_fields["LINK_IBLOCK_ID"];
			}
			
		    $arSelect = Array("ID", "NAME");
			$arFilter = Array("IBLOCK_ID" => $lIblockID, "INCLUDE_SUBSECTIONS" => "Y","PROPERTY_ORGANIZATION" => $organizationID,"ACTIVE"=>"Y");
			
			$res = CIBlockElement::GetList(Array("name"=>"asc"), $arFilter, false, Array(), $arSelect);
			while($ob = $res->GetNextElement()){ 

			  $arFields = $ob->GetFields();
			  $prop_fields["ENUM"][$arFields["ID"]] = $arFields["~NAME"]."  [".$arFields["ID"]."]";
			}
			
		   
	   }elseif($prop_fields["PROPERTY_TYPE"]=="G"){
		   
		    $prop_fields["ENUM"] = array();
			$lIblockID = $prop_fields["LINK_IBLOCK_ID"];
			
			
			$curSect = \SIMAI\Main\Configuration\Property::getValue(SF_SITE_DIR, $iblockLink[$lIblockID]);
			
			if(intval($curSect)){
				$rsParentSection = CIBlockSection::GetByID($curSect);
				if ($arParentSection = $rsParentSection->GetNext())
				{
				   $arFilter = array('IBLOCK_ID' => $arParentSection['IBLOCK_ID'],'>LEFT_MARGIN' => $arParentSection['LEFT_MARGIN'],'<RIGHT_MARGIN' => $arParentSection['RIGHT_MARGIN'],'>DEPTH_LEVEL' => $arParentSection['DEPTH_LEVEL']);
				   $rsSect = CIBlockSection::GetList(array('left_margin' => 'asc'),$arFilter);
				   while ($arSect = $rsSect->GetNext())
				   {
					  if($arSect["ACTIVE"] == "Y")
					    $prop_fields["ENUM"][$arSect["ID"]] = str_repeat(".", $arSect["DEPTH_LEVEL"] - 1).$arSect["~NAME"];
				   }
				}
				
			}
				
		   
	   }
	   elseif($prop_fields["USER_TYPE"] == "UserID"){
		   
		    $prop_fields["ENUM"] = array();
			$filter = Array();
			$rsUsers = CUser::GetList(($by = "LOGIN"), ($order = "asc"), $filter);
			while ($arUser = $rsUsers->Fetch()) {
			  $prop_fields["ENUM"][$arUser["ID"]] = $arUser["LOGIN"];
			}  
	   }
	   $arProperties[$prop_fields["CODE"]]=$prop_fields;
	}
	

	
	$flag_section=false;
	foreach($arConfig as $key=> $tab){
		
		foreach($tab["property"] as $code => $property){
			
		    if($code == "IBLOCK_SECTION_ID"){
		           $flag_section = true;
			       $arConfig[$key]["property"][$code]["multiple"]="Y";
			}
	    }	
	}
	
	if($flag_section){	
		$arProperties["IBLOCK_SECTION_ID"] = array();
		$arProperties["IBLOCK_SECTION_ID"]["ENUM"] = array();
	
	     if($_SERVER["SERVER_NAME"]==SITE_SERVER_NAME){
			 
			   $arFilter = array('IBLOCK_ID' => $_REQUEST["iblock"]); 
			   $rsSect = CIBlockSection::GetList(array('left_margin' => 'asc'),$arFilter);
			   while ($arSect = $rsSect->GetNext())
			   {
				   $arProperties["IBLOCK_SECTION_ID"]["ENUM"][$arSect["ID"]] = str_repeat(".", $arSect["DEPTH_LEVEL"]).$arSect["~NAME"];
			   } 
			 
			 
		 }else{
	
			$rsParentSection = CIBlockSection::GetByID($ROOT_SECTION);
			if ($arParentSection = $rsParentSection->GetNext())
			{
			   $arFilter = array('IBLOCK_ID' => $arParentSection['IBLOCK_ID'],'>LEFT_MARGIN' => $arParentSection['LEFT_MARGIN'],'<RIGHT_MARGIN' => $arParentSection['RIGHT_MARGIN'],'>DEPTH_LEVEL' => $arParentSection['DEPTH_LEVEL']); 
			   $rsSect = CIBlockSection::GetList(array('left_margin' => 'asc'),$arFilter);
			   while ($arSect = $rsSect->GetNext())
			   {
				   $arProperties["IBLOCK_SECTION_ID"]["ENUM"][$arSect["ID"]] = str_repeat(".", $arSect["DEPTH_LEVEL"] - 1).$arSect["~NAME"];
			   }
			}
		 }
	}
	$arCodeProperty=array();
	foreach($arConfig as $codeGroup => $group){
		
		if(is_array($group["property"])){
			
			
			foreach($group["property"] as $codeProp => $valProp){
				
				//на обязательность поля
				if($arResult["FIELDS"][$codeProp]["IS_REQUIRED"]=="Y" && $codeProp!="ACTIVE"){
					$arConfig[$codeGroup]["property"][$codeProp]["required"]="Y";
				}
			

				$cleanCode = str_replace("PROPERTY_", "",$codeProp);
				
				if($arProperties[$cleanCode]["IS_REQUIRED"] == "Y"){
					$arConfig[$codeGroup]["property"][$codeProp]["required"] = "Y";
				}
				
				if($arProperties[$cleanCode]["MULTIPLE"] == "Y"){
					$arConfig[$codeGroup]["property"][$codeProp]["multiple"] = "Y";
				}
				
				if(isset($arProperties[$cleanCode]["ENUM"])){
					
					$arConfig[$codeGroup]["property"][$codeProp]["values"] = $arProperties[$cleanCode]["ENUM"];
				}
				$arCodeProperty[$codeProp] = $valProp["type"];
			}
		}
		
	}
	




 
  $arAdditional = array("element-prop-edit-form" => "Y",
					    "iblock" => $_REQUEST["iblock"]);
						
  if(isset($_REQUEST["id"]))
	 $arAdditional["id"]=$_REQUEST["id"];
 
   
  if(isset($_REQUEST["id"])):
		$TITLE = $arConfig["ELEMENT_EDIT"];
  else:
		$TITLE = $arConfig["ELEMENT_ADD"];
  endif;			
?>

<?
    $arValues = array();
	
	if(!empty($valueElement)){
		
		foreach($valueElement as $code => $val){
			
			if($code == "PROPERTIES") continue;
			if(strpos($code,"~")===0) continue;
			
			
			if($code == "DETAIL_TEXT" || $code == "PREVIEW_TEXT"){
				$arValues[$code] = htmlspecialcharsbx($valueElement[$code]);
			}
			else{
				if(is_array($valueElement["~".$code]))
				   $arValues[$code] = $valueElement["~".$code];
				else
				   $arValues[$code] = htmlspecialchars_decode($valueElement["~".$code]);
			}
		}
		

		
		if(is_array($valueElement["PROPERTIES"])){
			
			foreach($valueElement["PROPERTIES"] as $code => $prop){
			 
			  
			  
			  $propertyValue ="";
			  if($prop["PROPERTY_TYPE"]=="L"){
				  if($arCodeProperty["PROPERTY_".$code] == "checkbox"){
					
					 if($prop["VALUE"]!="")
						$propertyValue = "Y";
					 else
						$propertyValue = "N";
				  }
				  else $propertyValue = $prop["VALUE_ENUM_ID"];
										
				}
				else if($prop["USER_TYPE"]=="simai_link"){
					
					$propertyValue = array();
					if(is_array($prop["VALUE"])){
						
						foreach($prop["VALUE"] as $k=>$v){
							$propertyValue[] = array("VALUE" => $v,"DESCRIPTION" => $prop["DESCRIPTION"][$k]);
						}
						
					}else
					   $propertyValue = $prop["VALUE"];
				}
				else if($prop["PROPERTY_TYPE"]=="S"){
																
					   if(isset($prop["~VALUE"]["TEXT"]))
							$propertyValue = $prop["VALUE"]["TEXT"];
					   else 
							$propertyValue = $prop["~VALUE"];
															
			   }
			  else $propertyValue = $prop["~VALUE"];
			  
			  $arValues["PROPERTY_".$code] = $propertyValue; 
		   }
		}								
	}

?>

<?
 unset($arConfig["ELEMENT_EDIT"]);
 unset($arConfig["ELEMENT_ADD"]);
 unset($arConfig["ELEMENT_DELETE"]);

 if($_REQUEST["section"]){
	$arValues["IBLOCK_SECTION_ID"] = $_REQUEST["section"];
 }
  if($_REQUEST["section"]){
	$arValues["IBLOCK_SECTION"] = $_REQUEST["section"];
 }
 
if(!isset($arValues["ACTIVE"]))
  $arValues["ACTIVE"] = "Y";


/*

echo "<pre>";
print_r($arConfig);
echo "</pre>";
*/
//echo $ROOT_SECTION;
?>
<?$APPLICATION->IncludeComponent(
	"simai:sf.property.edit",
	".default",
	Array(
		"TITLE" => $TITLE,
		"EXPERT_MODE" => Site::getValue(SF_SITE_DIR, 'expert_mode'),
		"DEFAULT_TEMPLATE" => "sf4",
		"ADDITIONAL_VALUES" => $arAdditional,
		"CONFIG" => $arConfig,
		"VALUES" => $arValues,
		"TYPE" => "array",
		"ARRAY_NAME" => "POST_SETTING",
	)
);?>

<?
 if(isset($GLOBALS["POST_SETTING"])){


   $el = new CIBlockElement;
   
   $arUpdateFields = Array();
   $arUpdateFields["PROPERTY_VALUES"]=array();
  
   foreach($arConfig as $arCategory):
     foreach($arCategory["property"] as $code => $property):
	 
		 $value = $GLOBALS["POST_SETTING"][$code];
		 $cleanCode = str_replace("PROPERTY_","",$code);

		 	 if($property["type"] == "file"){
				  
		   
			if(strpos($code, "PROPERTY_")===false){
				   
				foreach($GLOBALS["POST_SETTING"][$code] as $kfCode => $fVal){
					 
				    if($fVal["delete"] == "Y" && !isset($arUpdateFields[$code])) 
						$arUpdateFields[$code]= array("name"=>"","type"=>"","tmp_name"=>"","error"=>"4","size"=>"0",'del' => 'Y');
					
				/*	if(isset($fVal["description"])){
						$fVal["value"]["description"] = $fVal["description"];
					}*/
					
				    if(isset($fVal["value"]["tmp_name"])){
						
					  if(strlen($fVal["value"]["name"])>240){
						  
						  $tmpName = $fVal["value"]["name"];
						  $maxLenSize = 230;
						  $lenUtf = mb_strlen($tmpName);
						  $lenBase = strlen($tmpName);
						  $limit = intval(($maxLenSize*$lenUtf)/$lenBase);
						  $tmpName = mb_substr($tmpName,0,$limit);
						  
						  $extention = end(explode(".", $fVal["value"]["name"]));
		                  $extention = strtolower($extention);
						  $fVal["value"]["name"] = $tmpName.".".$extention;
						  
						  echo $fVal["value"]["name"];
					  }
					  
					  
					  $tmpFilesDir = \CTempFile::GetAbsoluteRoot();
					  $fVal["value"]["tmp_name"]=$tmpFilesDir.$fVal["value"]["tmp_name"];
					  $arUpdateFields[$code] = $fVal["value"];
				   }
				 }
				   
			   }else{
		
				   foreach($GLOBALS["POST_SETTING"][$code] as $kfCode=> $fVal){
					   
					   
					   $propValID = $valueElement["PROPERTIES"][$cleanCode]["PROPERTY_VALUE_ID"];
					   
					   
					   if($fVal["delete"] == "Y" || !isset($fVal["value"]["tmp_name"])){ 
					      if(is_array($propValID)){
							  $deleteID = $propValID[str_replace("n","",$kfCode)];
						  }else{
							  $deleteID = $propValID;
						  }
						  if($fVal["delete"] == "Y")
						      $arUpdateFields["PROPERTY_VALUES"][$cleanCode][$deleteID]= array("name"=>"","type"=>"","tmp_name"=>"","error"=>"4","size"=>"0",'del' => 'Y');
						  else
							  $arUpdateFields["PROPERTY_VALUES"][$cleanCode][$deleteID]= array("name"=>"","type"=>"","tmp_name"=>"","error"=>"4","size"=>"0","description" => $fVal["description"]); 
					   }
					   
					 /*  if(isset($fVal["description"])){
						  $fVal["value"]["description"] = $fVal["description"];
					   }*/

					   if(isset($fVal["value"]["tmp_name"])){
						   
						    if(strlen($fVal["value"]["name"])>240){
							  
							  $tmpName = $fVal["value"]["name"];
							  
							  $maxLenSize = 230;
							  $lenUtf = mb_strlen($tmpName);
							  $lenBase = strlen($tmpName);
							  $limit = intval(($maxLenSize*$lenUtf)/$lenBase);
							  $tmpName = mb_substr($tmpName,0,$limit);
							  
							  
							  
							  $extention = end(explode(".", $fVal["value"]["name"]));
							  $extention = strtolower($extention);
							  $fVal["value"]["name"] = $tmpName.".".$extention;
							  
							//  echo $fVal["value"]["name"];
						    }
					  
						    $tmpFilesDir = \CTempFile::GetAbsoluteRoot();
							$fVal["value"]["tmp_name"]=$tmpFilesDir.$fVal["value"]["tmp_name"];
							if($arProperties[$cleanCode]["MULTIPLE"]=="Y")
							   $arUpdateFields["PROPERTY_VALUES"][$cleanCode][] = $fVal["value"];
							else
								$arUpdateFields["PROPERTY_VALUES"][$cleanCode] = $fVal["value"];							
							 
					   } 
				   }
			   }
	     }else{
		 
			 if(strpos($code, "PROPERTY_")===false){
			   $arUpdateFields[$code] = $GLOBALS["POST_SETTING"][$code];
			 }
			 else{
				   if($arCodeProperty[$code] == "checkbox"){
					   
					   if($GLOBALS["POST_SETTING"][$code]=='Y')
						   $arUpdateFields["PROPERTY_VALUES"][$cleanCode] = key($arProperties[$cleanCode]["ENUM"]); 
					   else
						 $arUpdateFields["PROPERTY_VALUES"][$cleanCode] = ""; 
					 
				   }else{
			        $arUpdateFields["PROPERTY_VALUES"][$cleanCode] = $GLOBALS["POST_SETTING"][$code];
				   }
			 }
		 }
		  
		endforeach;
	 endforeach;
	 
	 if(is_array($arUpdateFields["IBLOCK_SECTION_ID"]))
		$arUpdateFields["IBLOCK_SECTION_ID"] = current($arUpdateFields["IBLOCK_SECTION_ID"]);
	
	if(!isset($arUpdateFields["IBLOCK_SECTION_ID"])||empty($arUpdateFields["IBLOCK_SECTION_ID"]))
		  $arUpdateFields["IBLOCK_SECTION_ID"] = $ROOT_SECTION;

 if(is_array($_POST["IBLOCK_SECTION_ID"])){
	 if(count($_POST["IBLOCK_SECTION_ID"])>1){
			  unset($arUpdateFields["IBLOCK_SECTION_ID"]);
			  $arUpdateFields["IBLOCK_SECTION"] = $_POST["IBLOCK_SECTION_ID"];
	  }
 }
	  
	  $arUpdateFields["PROPERTY_VALUES"]["ORGANIZATION"] = \SIMAI\Main\Configuration\Property::getValue(SF_SITE_DIR, "id");
	 
	 
	
	if(isset($arUpdateFields["PREVIEW_TEXT"])){
		$arUpdateFields["PREVIEW_TEXT_TYPE"] = "html";
	}
	if(isset($arUpdateFields["DETAIL_TEXT"])){
		$arUpdateFields["DETAIL_TEXT_TYPE"] = "html";
	}
	
	 	
	foreach($valueElement["PROPERTIES"] as $prop){
		
		if(!array_key_exists($prop["CODE"],$arUpdateFields["PROPERTY_VALUES"])){
			$arUpdateFields["PROPERTY_VALUES"][$prop["CODE"]] = $prop["VALUE"];
		}
	}

	global $USER;

	$arUpdateFields["MODIFIED_BY"] = $USER->GetID();
	
	
	//global $USER;
  // if(!$USER->IsAdmin()) {
	 
     if(isset($_POST["id"])){ 
	 
	 	$arUpdateFields["IPROPERTY_TEMPLATES"] = array(
			"ELEMENT_META_TITLE" =>"",
			"ELEMENT_META_KEYWORDS" =>"",
			"ELEMENT_META_DESCRIPTION" =>"",
			"ELEMENT_PAGE_TITLE" =>"",
			"ELEMENT_PREVIEW_PICTURE_FILE_ALT" => "",
			"ELEMENT_PREVIEW_PICTURE_FILE_TITLE" =>"",
			"ELEMENT_PREVIEW_PICTURE_FILE_NAME" =>"",
			"ELEMENT_DETAIL_PICTURE_FILE_ALT" =>"",
			"ELEMENT_DETAIL_PICTURE_FILE_TITLE" =>"",
			"ELEMENT_DETAIL_PICTURE_FILE_NAME" =>""
		);
		
        $el->Update($_POST["id"], $arUpdateFields);

			//логирование
			$fields = array(
				"SITE" => $settings["ID"],
				"TYPE" => "changeElem",
				"NAME" => $arUpdateFields["NAME"],
				"ID"   => $_POST["id"],
				"IBLOCK_ID" => $_REQUEST["iblock"]
			);
		 \SIMAI\Main\Utility\Log::add($fields);


	 }else{
		 
		 //проверка на дату
		 if(isset($arUpdateFields['ACTIVE_FROM']) && $arUpdateFields['ACTIVE_FROM']==""){ 
			 $arUpdateFields['ACTIVE_FROM'] = date('d.m.Y H:i');
		 }

		  $arUpdateFields["IBLOCK_ID"] = $_REQUEST["iblock"];
		  $el->Add($arUpdateFields);


		  //логирование
			$fields = array(
			    "SITE" => $settings["ID"],
				"TYPE" => "addElem",
				"NAME" => $arUpdateFields["NAME"],
				"ID"   => $_POST["id"],
				"IBLOCK_ID" => $_REQUEST["iblock"]
			);
		 \SIMAI\Main\Utility\Log::add($fields);
	
	 }
	 

	  LocalRedirect(str_replace($_SERVER["HTTP_ORIGIN"],"",$_SERVER["HTTP_REFERER"]));
	
  /* }else{
	   
	  
   }*/
   
   
 
 }
?>