<?
$MESS["SF_ADMIN_CONFIG__SECTION_CONFIG"] = "Настройки раздела";
$MESS["SF_ADMIN_CONFIG__EXPERT_MODE"] = "Экспертный режим";
$MESS["SF_ADMIN_CONFIG__BTN_SAVE"] = "Сохранить";
?>