<?
$MESS["SF_ADMIN_CONFIG__SITE_CONFIG"] = "Настройки сайта";
$MESS["SF_ADMIN_CONFIG__EXPERT_MODE"] = "Экспертный режим";
$MESS["SF_ADMIN_CONFIG__BTN_SAVE"] = "Сохранить";
?>