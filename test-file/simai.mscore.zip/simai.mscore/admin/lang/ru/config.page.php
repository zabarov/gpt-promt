<?
$MESS["SF_ADMIN_CONFIG__PAGE_CONFIG"] = "Настройки страницы";
$MESS["SF_ADMIN_CONFIG__EXPERT_MODE"] = "Экспертный режим";
$MESS["SF_ADMIN_CONFIG__BTN_SAVE"] = "Сохранить";
?>