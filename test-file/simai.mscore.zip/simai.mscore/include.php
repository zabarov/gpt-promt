<?
/**
* SIMAI Framework Solution Initialization
* 
* @author Rim Zabarov
* @copyright © SIMAI Studio 2018
* @version 4
*
* IMPORTANT!
* For work module you nedd add the contstant SF_SOLUTION width module name to /bitrix/php_interface/dbconn.php
* define("SF_SOLUTION", "simai.sf4eduportal"); 
*
*/
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php"); 

if(\Bitrix\Main\Loader::includeSharewareModule('simai.framework')==false) return;

global $USER;

use SIMAI\Main\Page\Asset;
use Bitrix\Main\Localization\Loc;

Loc::loadMessages(__FILE__);

\Bitrix\Main\Page\Asset::getInstance()->addString(Loc::getMessage('SF_SOLUTION_AUTHOR')); 
\Bitrix\Main\Page\Asset::getInstance()->addString(Loc::getMessage('SF_SOLUTION_COPYRIGHT')); 
\Bitrix\Main\Page\Asset::getInstance()->addString(Loc::getMessage('SF_SOLUTION_DISTRIBUTOR')); 

// set constants
define("SF_SOLUTION_NAME", Loc::getMessage('SF_SOLUTION_NAME'));
define("SF_SOLUTION_LINK", Loc::getMessage('SF_SOLUTION_LINK'));

define("SF_SOLUTION_PATH", __DIR__);
define("SF_SOLUTION_DIR", str_replace($_SERVER['DOCUMENT_ROOT'], '', __DIR__));





// for files edit from admin area
if(SITE_DIR == "") 
{
	$arUrl = parse_url($_SERVER["HTTP_REFERER"]);
	$obPath = new \SplFileInfo($arUrl["path"]);
	$pathUrl = $obPath->getPath();
	
	// for index directory
	if($pathUrl == "") 
		$pathUrl = $obPath->getFilename();
	
	$arSiteDir = array();
	$rsSites = CSite::GetList($by="sort", $order="desc",array());

	while ($arSite = $rsSites->Fetch())
	{
		if($arSite["DIR"] != "/") 
		{
			$dirSite = 	substr($arSite["DIR"], 0, -1);
			$lenSiteDir = strlen($dirSite);
			if($dirSite == substr($pathUrl, 0, $lenSiteDir)){
				define("SF_SITE_DIR", $dirSite); 
				break;
			}
		}
	}

    if(!defined('SF_SITE_DIR')) {
			define("SF_SITE_DIR", "/");
	}
}
elseif (substr(SITE_DIR, -1) == "/" && strlen(SITE_DIR)>1) 
{
	define("SF_SITE_DIR", substr(SITE_DIR, 0, -1)); 
}
else 
{
	define("SF_SITE_DIR", SITE_DIR);
}	

define("SF_LANG", preg_replace("'[\\\\/]+'", "", SF_SITE_DIR));
define("SF_DATA_DIR", preg_replace("'[\\\\/]+'", "/", SF_SITE_DIR . "/simai.data"));
define("SF_SITE_PATH", $_SERVER["DOCUMENT_ROOT"] . SF_SITE_DIR);
define("SF_DATA_PATH", $_SERVER["DOCUMENT_ROOT"] . SF_DATA_DIR);

// include module class 
\Bitrix\Main\Loader::registerAutoLoadClasses(SF_SOLUTION, array(
	//"\SIMAI\Main\Configuration\Iblock" 		=> "lib/configuration/iblock.php",
	//"\SIMAI\Main\Configuration\Transfer" 	=> "lib/configuration/transfer.php",	
	"\SIMAI\Main\IO\IncludeArea" 			=> "lib/io/include_area.php",
	//"\SIMAI\Main\IO\Setting" 				=> "lib/io/setting.php",
	//"\SIMAI\Main\Fileman\Property" 			=> "lib/fileman/property.php",
	//"\SIMAI\Main\Block\Section" 			=> "lib/block/section.php",
	"\SIMAI\Main\Block\Edit" 				=> "lib/block/edit.php",
	"\SIMAI\Main\Config\Site" 				=> "lib/config/site.php",
	"\SIMAI\Main\Config\Portal" 			=> "lib/config/portal.php",
	"\SIMAI\Main\Config\IblockElement" 		=> "lib/config/iblockelement.php",
	"\SIMAI\Main\Config\IblockSection" 		=> "lib/config/iblocksection.php",
	"\SIMAI\Main\Config\Structure" 			=> "lib/config/structure.php",
	"\SIMAI\Main\Config\Component" 			=> "lib/config/component.php",
	"\SIMAI\Main\Config\Sveden" 			=> "lib/config/sveden.php",
	//"\SIMAI\Main\Utility\Text" 				=> "lib/utility/text.php",
	//"\SIMAI\Main\Utility\File" 				=> "lib/utility/file.php",
	//"\SIMAI\Main\Utility\Data" 				=> "lib/utility/data.php",
	"\SIMAI\Main\Utility\Document" 			=> "lib/utility/document.php",
	"\SIMAI\Main\Utility\Sveden" 			=> "lib/utility/sveden.php",
	"\SIMAI\Main\Subsite\Coordinate"        => "lib/subsite/coordinate.php", 
	"\SIMAI\Main\Subsite\Tree"              => "lib/subsite/tree.php",
    "\SIMAI\Main\Subsite\Verification"      => "lib/subsite/verify.php",
	"\SIMAI\Main\Utility\Breadcrumb"        => "lib/utility/breadcrumb.php",
	"\SIMAI\Main\Utility\Menu" 				=> "lib/utility/menu.php",
	"\SIMAI\Main\Subsite\Register" 			=> "lib/subsite/register.php",
	"\SIMAI\Task\Editor" 			        => "lib/task/editor.php",
	"\SIMAI\Task\Manager" 		            => "lib/task/manager.php",
	"\SIMAI\Main\Utility\Log" 			    => "lib/utility/log.php",
	"\SIMAI\Disk\Disk" 			            => "lib/disk/disk.php",
	"\SIMAI\Task\Delete" 		            => "lib/task/delete.php"
	
	
));

// set images for lazyload
define("SF_IMAGE_BLANK", "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==");
define("SF_IMAGE_LAZYLOAD_BG", \SIMAI\Main\Configuration\Property::getInstance()->get(SF_SITE_DIR, 'image_lazyload_bg'));


// set specials property for admin
if($USER->IsAdmin())
{
	$arProperty = array("demo_mode");
	
	foreach($arProperty as $property)
	{
		if($_GET[$property])
			SIMAI\Main\Configuration\Site::setValue(SF_SITE_DIR, $property, $_GET[$property]);
	}
}
?>
