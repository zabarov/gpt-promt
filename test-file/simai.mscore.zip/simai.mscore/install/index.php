<?
use Bitrix\Main\Localization\Loc;
Loc::loadMessages(__FILE__); 

class simai_mscore extends CModule
{
	const MODULE_ID = "simai.mscore";
	var $MODULE_ID = "simai.mscore";
	var $MODULE_VERSION;
	var $MODULE_VERSION_DATE;
	var $MODULE_NAME;
	var $MODULE_DESCRIPTION;
	var $MODULE_CSS;
	var $strError = '';

	function __construct()
	{
		$arModuleVersion = array();
		include(dirname(__FILE__)."/version.php");
		$this->MODULE_VERSION = $arModuleVersion["VERSION"];
		$this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
		$this->MODULE_NAME = Loc::getMessage("SIMAI.mscore__MODULE_NAME");
		$this->MODULE_DESCRIPTION = Loc::getMessage("SIMAI.mscore__MODULE_DESC");
		$this->PARTNER_NAME = Loc::getMessage("SIMAI.mscore__PARTNER_NAME");
		$this->PARTNER_URI = Loc::getMessage("SIMAI.mscore__PARTNER_URI");
	}

	function InstallDB($arParams = array())
	{
		return true;
	}

	function UnInstallDB($arParams = array())
	{
		return true;
	}

	function InstallEvents()
	{
		return true;
	}

	function UnInstallEvents()
	{
		return true;
	}

	function InstallFiles($arParams = array())
	{
		

	}

	function UnInstallFiles()
	{
	}

	function DoInstall()
	{
		global $APPLICATION;
		
		
		if(!file_exists($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.framework/"))
        {
          //разархивировать модуль
		  
		   $arUnpackOptions = Array(
			   "UNPACK_REPLACE"   => true
			);

		  $resArchiver = CBXArchive::GetArchive($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/" . self::MODULE_ID . "/install/wizard/data/module/simai.framework.zip");
		  $resArchiver->SetOptions($arUnpackOptions);
		  $uRes = $resArchiver->Unpack($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/");
		  
		  
		  //скопировать папки
		  CheckDirPath($_SERVER["DOCUMENT_ROOT"]."/bitrix/components/simai");
		  CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.framework/install/components/simai", $_SERVER["DOCUMENT_ROOT"]."/bitrix/components/simai", true, true);
          CheckDirPath($_SERVER["DOCUMENT_ROOT"]."/bitrix/wizards/simai");
		  CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.mscore/install/wizard/simai.mscore", $_SERVER["DOCUMENT_ROOT"]."/bitrix/wizards/simai/simai.mscore", true, true);

		  CheckDirPath($_SERVER["DOCUMENT_ROOT"]."/simai");
		  CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.framework/install/simai", $_SERVER["DOCUMENT_ROOT"]."/simai", true, true);

		
		  //зарегистрировать модуль
          RegisterModule("simai.framework");
			
        }
	    if(!file_exists($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property/"))
        {
          //разархивировать модуль
		  
		   $arUnpackOptions = Array(
			   "UNPACK_REPLACE"   => true
			);

		  $resArchiver = CBXArchive::GetArchive($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/" . self::MODULE_ID . "/install/wizard/data/module/simai.property.zip");
		  $resArchiver->SetOptions($arUnpackOptions);
		  $uRes = $resArchiver->Unpack($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/");
		  
		  
		  $arParams = array('properties_folder' => "",'prop_folder' => "");
		  
		  if ($arParams['properties_folder'] == 'custom' && $arParams['prop_folder'])
		  {
				$arParams['prop_folder'] = htmlspecialcharsex(str_replace('.','',$arParams['prop_folder']));		
				\Bitrix\Main\IO\Directory::createDirectory($_SERVER["DOCUMENT_ROOT"].$arParams['prop_folder']);
				
				CopyDirFiles($_SERVER["DOCUMENT_ROOT"].'/bitrix/modules/simai.property/property/', $_SERVER["DOCUMENT_ROOT"].$arParams['prop_folder'], true, true);
				
				\Bitrix\Main\Config\Option::set('simai.property', 'folder_path', $arParams['prop_folder']);
		  }
			
		  \Bitrix\Main\IO\Directory::createDirectory($_SERVER["DOCUMENT_ROOT"].'/simai/admin');
		  CopyDirFiles($_SERVER["DOCUMENT_ROOT"].'/bitrix/modules/simai.property/install/simai/admin/', $_SERVER["DOCUMENT_ROOT"].'/simai/admin');
		  CopyDirFiles($_SERVER["DOCUMENT_ROOT"].'/bitrix/modules/simai.property/install/admin/', $_SERVER["DOCUMENT_ROOT"].'/bitrix/admin');
		  CopyDirFiles($_SERVER["DOCUMENT_ROOT"].'/bitrix/modules/simai.property/install/js/', $_SERVER["DOCUMENT_ROOT"].'/bitrix/js', true, true);
	
		  //зарегистрировать модуль
          RegisterModule("simai.property");
			
        }
		
	    if(!file_exists($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/"))
        {
          //разархивировать модуль
		  
		   $arUnpackOptions = Array(
			   "UNPACK_REPLACE"   => true
			);

		  $resArchiver = CBXArchive::GetArchive($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/" . self::MODULE_ID . "/install/wizard/data/module/simai.property4iblock.zip");
		  $resArchiver->SetOptions($arUnpackOptions);
		  $uRes = $resArchiver->Unpack($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/");
		  
		  CopyDirFiles(SF_DOCUMENT_ROOT.'/bitrix/modules/simai.property4iblock/install/components/simai/', SF_DOCUMENT_ROOT.'/bitrix/components/simai', true, true);
		  CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/simai.property4iblock/install/admin", $_SERVER["DOCUMENT_ROOT"]."/bitrix/admin");
		  
		  RegisterModule("simai.property4iblock");
			
		  RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiTask", "GetUserTypeDescription");
		  RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiIBElement", "GetUserTypeDescription");
		  RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiIBSection", "GetUserTypeDescription");
		  RegisterModuleDependences("iblock", "OnIBlockPropertyBuildList", "simai.property4iblock", "CCustomTypeSimaiLink", "GetUserTypeDescription");
	
        }
		
		CheckDirPath($_SERVER["DOCUMENT_ROOT"]."/simai/wizard/master/" . self::MODULE_ID . "/data");
		CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/" . self::MODULE_ID . "/install/wizard/data", $_SERVER["DOCUMENT_ROOT"]."/simai/wizard/master/" . self::MODULE_ID . "/data", true, true);
		
		RegisterModule(self::MODULE_ID);
		RegisterModuleDependences("main", "OnEpilog", self::MODULE_ID, "SF_Event", "Check404Error");
		
		LocalRedirect("/simai/wizard/master/" . self::MODULE_ID . "/");
	}

	function DoUninstall()
	{
		global $APPLICATION;
		UnRegisterModule(self::MODULE_ID);
	
	}
}
?>