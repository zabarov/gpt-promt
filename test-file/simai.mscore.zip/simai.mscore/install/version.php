<?
$arModuleVersion = array(
	"VERSION" => "1.0.0",
	"VERSION_DATE" => "2015-12-01 18:03:07"
);
?>