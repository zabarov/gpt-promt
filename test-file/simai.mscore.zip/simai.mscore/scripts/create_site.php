<?
CModule::IncludeModule("iblock");
CModule::IncludeModule("simai.mscore");
\Bitrix\Main\Loader::includeModule("highloadblock"); 


$max_time = 5;
//засекаем время
$start_timer = time();



//$arData["ID"]  id задания
//$arData["PARAMS"]["ID"]

if(!intval($arData["PARAMS"]["ID"])) die();

//смена статуса на "в работе"
$hlbl = 11;
$hlblock = Bitrix\Highloadblock\HighloadBlockTable::getById($hlbl)->fetch(); 
$entity = Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock); 
$entity_data_class = $entity->getDataClass(); 

$rsData = $entity_data_class::getList(array(
	"select" => array("UF_SFCRON__STATUS","ID"),
	"order" => array("ID" => "ASC"),
	"filter" => array("ID" => $arData["ID"])  
 ));
 
 if($arCron = $rsData->Fetch()){

	if($arCron["UF_SFCRON__STATUS"] == '74'){
       $data = array("UF_SFCRON__STATUS" => '75');
       $entity_data_class::update($arCron["ID"], $data);
	}
 } 





/*
данные айдишник задания
*/


$res = CIBlockElement::GetByID($arData["PARAMS"]["ID"]);
if($ar_res = $res->GetNext()){

    $iblockID = $ar_res["IBLOCK_ID"];
    $typeOrg =  $ar_res["IBLOCK_CODE"];

    $struct = $ar_res["DETAIL_TEXT"];

    $propSections = array(); 
	$arSelect = Array("ID", "IBLOCK_ID", "NAME", "PROPERTY_*");
	$arFilter = Array("IBLOCK_ID"=> $ar_res["IBLOCK_ID"], "ID" => $ar_res["ID"]);
	$res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
	if($ob = $res->GetNextElement()){ 

		 $arProps = $ob->GetProperties();
		 foreach($arProps as $code =>$prop){

			 if($prop["PROPERTY_TYPE"] == "G" && $prop["VALUE"] == ""){
                  $propSections[$code] = $prop;
              }
          }
	}

	$arSelect = Array("ID", "NAME", "IBLOCK_ID", "PROPERTY_TYPE", "PROPERTY_HIGHLOADBLOCK");
	$arFilter = Array("IBLOCK_ID"=> 87, "PROPERTY_TYPE" => $typeOrg);
	$res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
	if($ob = $res->GetNextElement())
	{
	  $arFields = $ob->GetFields();
	  $hlbl = $arFields["PROPERTY_HIGHLOADBLOCK_VALUE"];
	} 

  }
  else{
	  
	    $hlbl = 11;
		$hlblock = Bitrix\Highloadblock\HighloadBlockTable::getById($hlbl)->fetch(); 
		$entity = Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock); 
		$entity_data_class = $entity->getDataClass(); 

		$data = array("UF_SFCRON__STATUS" => '76');
		$entity_data_class::update($arData["ID"], $data);
	  
        return;
		
  }






//проверка на структуру сайта если нет создаём
if($struct==""){


    //получаем список структуры
	$struct = require $_SERVER["DOCUMENT_ROOT"]."/".$typeOrg."/.params/.site.structure.php";

	//из числового делаем ассоциативный массив
    $arId = array();
	$tmp = array();
	foreach($struct as $str){
		$tmp[$str["path"]] = $str;
	}

	$struct = $tmp;
	$hlblock = Bitrix\Highloadblock\HighloadBlockTable::getById($hlbl)->fetch(); 
	$entity = Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock); 
	$entity_data_class = $entity->getDataClass(); 

	$org = $arData["PARAMS"]["ID"];
	
	$typeOrgCode = strtoupper($typeOrg);
	
	
	foreach ($struct as $code => $val){

		// Массив полей для добавления
		$data = array(
			  "UF_".$typeOrgCode."_STRUCTURE__NAME"  => $val["name"],
			  "UF_".$typeOrgCode."_STRUCTURE__CODE" => $val["code"],
			  "UF_".$typeOrgCode."_STRUCTURE__SORT"  => $val["sort"],
			  "UF_".$typeOrgCode."_STRUCTURE__ORGANIZATION"  => $org,
			  "UF_".$typeOrgCode."_STRUCTURE__BASE"  => 1,
			  "UF_".$typeOrgCode."_STRUCTURE__SECTION"  => $arId[$val["section"]],
			  "UF_".$typeOrgCode."_STRUCTURE__PAGE"  => 0
		   );
		   
		 if($val['type'] == 'page')
		    $data["UF_".$typeOrgCode."_STRUCTURE__PAGE"] = 1;
			
		 if($val['type_menu'] != '')	
	         $data["UF_".$typeOrgCode."_STRUCTURE__TYPE_MENU"] = $val['type_menu'];
			 
		$result = $entity_data_class::add($data);
		
		if($result->isSuccess()){                    
		  $arId[$val["path"]] = $result->getId(); 
		}
 
	}
	
	//вычисляем структуру сайта
	$tree_content = \SIMAI\Main\Subsite\Tree::Get($org);

    $el = new CIBlockElement;
	$arAddFields = Array("DETAIL_TEXT" => $tree_content);   
    $el->Update($org, $arAddFields);

  //обновляем свойство у элемента
  return;
}

$subSections = require $_SERVER["DOCUMENT_ROOT"]."/".$typeOrg."/.params/.section.params.php";

//цикл по разделам и привязкам
foreach($propSections as $code => $prop){


     //добавляем
    if(intval($prop["LINK_IBLOCK_ID"])){

        $res = CIBlock::GetByID($prop["LINK_IBLOCK_ID"]);
        if($ar_res = $res->GetNext()){

            
               $bs = new CIBlockSection;
               $arAddFields = Array(
                    "ACTIVE" => "Y",
                    "IBLOCK_SECTION_ID" => false,
                    "IBLOCK_ID" => $ar_res["ID"],
                    "NAME" => $arData["PARAMS"]["ID"],
                    "UF_BASE" => 1,
               );

              $idRootSection = $bs->Add($arAddFields);

			  
              //обновляем свойство
			  CIBlockElement::SetPropertyValueCode($arData["PARAMS"]["ID"], $prop['CODE'], $idRootSection);

			  //добавляем разделы доп разделов
			  foreach($subSections as $subSect){

				  //определяем 
				  if($subSect['iblock'] == $ar_res['CODE']){

					$bs = new CIBlockSection;
					$arAddFields = Array(
							  "ACTIVE" => "Y",
							  "IBLOCK_SECTION_ID" => $idRootSection,
							  "IBLOCK_ID" => $ar_res["ID"],
							  "NAME" => $subSect["name"],
							  "CODE" => $idRootSection."_".$subSect["code"],
							  "UF_BASE" => 1,
					);

					 
					if(isset($subSect["sort"])) $arAddFields["SORT"] = $subSect["sort"];
					$newSubsection = $bs->Add($arAddFields);


                    //создавать элементы
					if(intval($subSect["copy_elems"]) && intval($newSubsection)){
								
						//по ид получить раздел и инфоблок

						$res = CIBlockSection::GetByID(intval($subSect["copy_elems"]));
						if($ar_res = $res->GetNext()){

							//сделать выборку элементов
							$arAddelems = array();
							$arSelect = Array("ID", "IBLOCK_ID", "NAME", "SORT", "PREVIEW_TEXT","DETAIL_TEXT","PREVIEW_PICTURE","DETAIL_PICTURE","PROPERTY_*");
							$arFilter = Array("IBLOCK_ID"=> $ar_res["IBLOCK_ID"], "SECTION_ID" => $ar_res["ID"], "ACTIVE"=>"Y");
							$res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
							while($ob = $res->GetNextElement()){ 

					
								$element = array();
								$arFields = $ob->GetFields();  
								$arProps = $ob->GetProperties();
								$element["NAME"] = $arFields["~NAME"];
								$element["SORT"] = $arFields["SORT"];
								$element["IBLOCK_ID"] = $ar_res["IBLOCK_ID"];

								if($arFields["PREVIEW_TEXT"]) $element["PREVIEW_TEXT"] = $arFields["~PREVIEW_TEXT"];
								if($arFields["DETAIL_TEXT"]) $element["DETAIL_TEXT"] = $arFields["~DETAIL_TEXT"];
								if(intval($arFields["PREVIEW_PICTURE"]))  $element["PREVIEW_PICTURE"] = CFile::MakeFileArray($arFields["PREVIEW_PICTURE"]); 
								if(intval($arFields["DETAIL_PICTURE"]))   $element["DETAIL_PICTURE"] = CFile::MakeFileArray($arFields["DETAIL_PICTURE"]);
								
								$element["PROPS"] = array();
								foreach($arProps as $code => $prop){

									if($prop["MULTIPLE"] == "N"){

										if($prop["VALUE"]!=""){

											if($prop["USER_TYPE"] == "HTML"){
												$element["PROPS"][$code] =  $prop["~VALUE"]['TEXT'];
											}
											elseif($prop["PROPERTY_TYPE"] == "F"){
												$element["PROPS"][$code] =  CFile::MakeFileArray($prop["VALUE"]);
											}else{
												$element["PROPS"][$code] =  $prop["~VALUE"];
											}

										}
									}
									elseif(!empty($prop["VALUE"])){

										$element["PROPS"][$code] = array();
										foreach($prop["~VALUE"] as $pVal){

											if($pVal!=""){

												if($prop["USER_TYPE"] == "HTML"){
													$element["PROPS"][$code][] =  $pVal;
												}
												elseif($prop["PROPERTY_TYPE"] == "F"){
													$element["PROPS"][$code][] =  CFile::MakeFileArray($pVal);
												}else{
													$element["PROPS"][$code][] =  $pVal;
												}

											}
										}
									}	
								}	
								$element["PROPS"]['ORGANIZATION'] = $arData["PARAMS"]["ID"];
								$element["IBLOCK_SECTION_ID"] = $newSubsection;
								
						
								$arAddelems[] = $element;
							}


							//добавить элементы
							$el = new CIBlockElement;

							foreach($arAddelems as $element){
							$element["PROPERTY_VALUES"] = $element["PROPS"];
							unset($element["PROPS"]);
							$el->Add($element);
							}
						}
					}






				  }






			  }

        }
     }


   //проверяем время, если истекло то return;
   $time = time() - $start_timer;
   if($time > $max_time){
     return;
   }
    
}



	//дошли до этого шага


	//смена статуса на выполнено
	$hlbl = 11;
	$hlblock = Bitrix\Highloadblock\HighloadBlockTable::getById($hlbl)->fetch(); 
	$entity = Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock); 
	$entity_data_class = $entity->getDataClass(); 

	$data = array("UF_SFCRON__STATUS" => '76');
	$entity_data_class::update($arData["ID"], $data);
	
	
	//дополнительно проверяем привязки к разделам
    $arSelect = Array("ID", "IBLOCK_ID", "NAME", "PROPERTY_*");
	$arFilter = Array("IBLOCK_ID"=> $iblockID, "ID" => $arData["PARAMS"]["ID"]);
	$res = CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
	if($ob = $res->GetNextElement()){ 

		 $arProps = $ob->GetProperties();
		 foreach($arProps as $code =>$prop){

			 if($prop["PROPERTY_TYPE"] == "G" && $prop["VALUE"] == ""){

				   //найти раздел с названием и привязать его
				   $arFilter = array('IBLOCK_ID' => $prop['LINK_IBLOCK_ID'], "NAME" => $arData["PARAMS"]["ID"], "SECTION_ID" => false);
                   $rsSect = CIBlockSection::GetList(array('left_margin' => 'asc'),$arFilter); 
				   if ($arSect = $rsSect->GetNext()){
                         CIBlockElement::SetPropertyValueCode($arData["PARAMS"]["ID"], $prop["CODE"], $arSect["ID"]);
				   }
              }
          }
	}
	





	//установка статуса сайта "на модерацию"
	$arProps = CIBlockPropertyEnum::GetList(Array("SORT" => "ASC", "VALUE" => "ASC"), Array("IBLOCK_ID" => $iblockID, "CODE" => "STATUS", "XML_ID" => 'moderate'));										
	$enum = array();
	if($arProp = $arProps->Fetch()){	
	   CIBlockElement::SetPropertyValueCode($arData["PARAMS"]["ID"], "STATUS", $arProp["ID"]);
	}


	//перерасчёт кеша по домену
	$arSelect = Array("ID", "NAME", "IBLOCK_ID", "PROPERTY_ORGANIZATION");
	$arFilter = Array("IBLOCK_ID"=> 67, "PROPERTY_ORGANIZATION" => $arData["PARAMS"]["ID"]);
	$res = CIBlockElement::GetList(Array(), $arFilter, false, array(), $arSelect);
	if($ob = $res->GetNextElement())
	{
	    $arFields = $ob->GetFields();
	    \SIMAI\Main\Subsite\Coordinate::GetCashe($arFields["NAME"], true);
	}


?>