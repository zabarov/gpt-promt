<?
namespace SIMAI\Main\Config;

use Bitrix\Main;

class Site
{
	/**
	 * @var Configuration
	 */

	const DIR_SYSTEM_CONF = '/simai.data/config/system/site/';
	const DIR_USER_CONF = '/simai.data/config/user/site/';
	
	public static function get($type)
	{
		$systemPath = Main\Loader::getDocumentRoot().self::DIR_SYSTEM_CONF.".".$type.".php";
		$userPath = Main\Loader::getDocumentRoot().self::DIR_USER_CONF.".".$type.".php";
		
		if(file_exists($systemPath))
		  $systemConf = require $systemPath;
	    else
		  return false;
	  
	    if(file_exists($userPath)){
		    $userConf = require $userPath;
			$systemConf = array_merge($systemConf, $userConf);
		}
		return $systemConf;
	}
	
	private function __construct()
	{
	}
}

?>