<?
//only portal
namespace SIMAI\Main\Subsite;

	class Tree{  
	  
	   static function Get($idOrg)
	   {
		   
		  // use Bitrix\Main\Entity;
		   \Bitrix\Main\Loader::includeModule("highloadblock"); 
		   \Bitrix\Main\Loader::includeModule("iblock"); 

			
			//найти ид блока
			
			$res = \CIBlockElement::GetByID(intval($idOrg));
			if($ar_res = $res->GetNext()){
				
				$arSelect = Array("ID", "IBLOCK_ID", "NAME", "DATE_ACTIVE_FROM","PROPERTY_*");
				$arFilter = Array("IBLOCK_ID" => \COption::GetOptionString("simai.eduportal", "type_iblock", ""), "PROPERTY_IBLOCK" => $ar_res['IBLOCK_ID']);
				$res = \CIBlockElement::GetList(Array(), $arFilter, false, Array(), $arSelect);
				if($ob = $res->GetNextElement()){ 
				
				  $arFields = $ob->GetFields();  
				  $arProps  = $ob->GetProperties();
				  $hlbl = $arProps["HIGHLOADBLOCK"]["VALUE"];
				  $typeOrg = strtoupper($arProps["TYPE"]["VALUE"]);
				}
			}
			
			$hlblock = \Bitrix\Highloadblock\HighloadBlockTable::getById($hlbl)->fetch(); 

			$entity = \Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock); 
			$entity_data_class = $entity->getDataClass(); 

			$rsData = $entity_data_class::getList(array(
			   "select" => array("*"),
			   "order" => array("UF_".$typeOrg."_STRUCTURE__SORT" => "ASC"),
			   "filter" => array("UF_".$typeOrg."_STRUCTURE__ORGANIZATION" => $idOrg)
			));

			$parent = array();
			//пункты меню
			$itemsMenu = array();
			//корневое меню
			$rootMenu = array();
			while($arData = $rsData->Fetch()){
				
				$itemsMenu[$arData["ID"]] = $arData;
				if(intval($arData["UF_".$typeOrg."_STRUCTURE__SECTION"])){
					$parent[$arData["UF_".$typeOrg."_STRUCTURE__SECTION"]][] = $arData["ID"];
				}
				else{
					$rootMenu[$arData["ID"]] = $arData;
				}
			}
			

			
			$arMenu = array();
			
			foreach($rootMenu as $id => $item){
				
				$menuItem = self::returnItem($item,"/", 0, $parent,$typeOrg);
				$arMenu[$menuItem["LINK"]] = $menuItem;
				
				if(isset($parent[$id])){
					$arMenu = self::getSubMenu($id, $itemsMenu, $parent, $arMenu, $menuItem,$typeOrg);
				}
			}
		  
			return serialize($arMenu);
		}
		
		
		
		
		private static function returnItem($item, $parentLink, $depthLevel, $parent,$typeOrg){
			 
			 $result = array();
			 $result["ID"] =   $item["ID"];
			 $result["NAME"] = $item["UF_".$typeOrg."_STRUCTURE__NAME"];
			 $result["SORT"] = $item["UF_".$typeOrg."_STRUCTURE__SORT"];
			 $result["LINK"] = $parentLink.$item["UF_".$typeOrg."_STRUCTURE__CODE"];
			 $result["TYPE_MENU"] = $item["UF_".$typeOrg."_STRUCTURE__TYPE_MENU"];
			 $result["HIDE"] = $item["UF_".$typeOrg."_STRUCTURE__HIDE"];
			 $result["TIMESTAMP_X"] = $item["UF_".$typeOrg."_STRUCTURE__TIMESTAMP_X"];
			 
			 if($item["UF_".$typeOrg."_STRUCTURE__PAGE"]){
				  $result["PAGE"] = "Y";
				  $result["LINK"].= ".php";
			 }else{
				 $result["LINK"].= "/";
				 $result["PAGE"] = "N";
			 }
			 $result["DEPTH_LEVEL"] = $depthLevel+1;
			 
			 if(isset($parent[$item["ID"]]))
				$result["IS_PARENT"] = "Y";
			 else
				$result["IS_PARENT"] = "N";
			 
			 return $result;
		 }
	 
	 
		 private static function getSubMenu($id, $itemsMenu, $parent,$output, $menuItem,$typeOrg){
			 
			 foreach($parent[$id] as $itemID){
				 
				 $subMenuItem = self::returnItem($itemsMenu[$itemID], $menuItem["LINK"], $menuItem["DEPTH_LEVEL"], $parent,$typeOrg);
				 $output[$subMenuItem["LINK"]] = $subMenuItem;

				 if(isset($parent[$itemID])){
					 $output = self::getSubMenu($itemID, $itemsMenu, $parent, $output, $subMenuItem,$typeOrg);  
				 }
			 } 
			 return $output;
		 }
		
		
	}