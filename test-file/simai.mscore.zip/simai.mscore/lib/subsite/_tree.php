<?
//only portal
namespace SIMAI\Main\Subsite;

	class Tree{  
	  
	   static function Get($parentSectionID)
	   {
		   
		 if (\CModule::IncludeModule("iblock")):


			$rsParentSection = \CIBlockSection::GetByID($parentSectionID);
			if ($arParentSection = $rsParentSection->GetNext())
			{

				$arRes=array();
				$arSelect = Array("ID", "NAME", "CODE","SORT","IBLOCK_ID","IBLOCK_SECTION_ID");
				$arFilter = Array("IBLOCK_ID"=> $arParentSection['IBLOCK_ID'],"SECTION_ID" => $arParentSection["ID"], "INCLUDE_SUBSECTIONS" => "Y", "ACTIVE"=>"Y");
				$res = \CIBlockElement::GetList(Array("sort"=>"asc"), $arFilter, false, Array("nPageSize"=>500), $arSelect);
				while($ob = $res->GetNextElement())
				{
				 $arFields = $ob->GetFields();
				 $arRes[$arFields["IBLOCK_SECTION_ID"]][]=array("ID" => $arFields["ID"], "SORT" => $arFields["SORT"], "CODE" => $arFields["CODE"],"NAME" =>$arFields["NAME"]);
				}	
				

				 $arFilter = array('IBLOCK_ID' => $arParentSection['IBLOCK_ID'],'>LEFT_MARGIN' => $arParentSection['LEFT_MARGIN'],'<RIGHT_MARGIN' => $arParentSection['RIGHT_MARGIN'],'>DEPTH_LEVEL' => $arParentSection['DEPTH_LEVEL']); 
				 $rsSect = \CIBlockSection::GetList(array('left_margin' => 'asc','sort'=>'asc'),$arFilter);
				 $depthLevel=2;
				 $links=array();
				 $arMenu=array();
				 //содержит предыдущий код
				 $tmpCode="";
				 $arDepth=array();
				 while ($arSect = $rsSect->GetNext())
				 {
					 if($depthLevel==$arSect["DEPTH_LEVEL"]){
						 
						  $tmpCode = $arSect["CODE"];
						  
					 }elseif($depthLevel < $arSect["DEPTH_LEVEL"]){
						 
						 array_push($links,$tmpCode);
						 $tmpCode = $arSect["CODE"];
						 $depthLevel=$arSect["DEPTH_LEVEL"];
						 $arMenu[$before_punkt]["IS_PARENT"]="Y";
					 }
					 elseif($depthLevel>$arSect["DEPTH_LEVEL"]){
						 
						
						 
						  $depthLevel=$arSect["DEPTH_LEVEL"];
						  $tmpCode = $arSect["CODE"];
						  while(count($links)>$depthLevel-2)
						    $fruit = array_pop($links);
						
						
					 }
					 
					 
					  
					  if(!empty($links))
						 $parentPath="/".implode("/", $links)."/";
					  else
						 $parentPath="/";
					 
					 
					if(count($arDepth) < $arSect["DEPTH_LEVEL"]-1){
						 
						 $arDepth[$arSect["DEPTH_LEVEL"]] = $arSect;
					 }
					 else if(count($arDepth) == $arSect["DEPTH_LEVEL"]-1){
						 
						//для подпунктов меню
						if(isset($arRes[$arDepth[$arSect["DEPTH_LEVEL"]]["ID"]])){
							 
							  $tmppath="/";
							  foreach($arDepth as $sectDepth){
								  $tmppath.=$sectDepth["CODE"]."/";
							  }
							  
							  foreach($arRes[$arDepth[$arSect["DEPTH_LEVEL"]]["ID"]] as $pageMenu){
								  
								  $arMenu[$tmppath.$pageMenu["CODE"].".php"]=array(
									 "ID" => $pageMenu["ID"],
									 "NAME" => $pageMenu["NAME"],
									 "SORT" => $pageMenu["SORT"],
									 "LINK" => $tmppath.$pageMenu["CODE"].".php",
									 "PAGE" => "Y",
									 "DEPTH_LEVEL" => $arSect["DEPTH_LEVEL"],
									 "IS_PARENT" => "N",
								   );
						 
							    }	
						}
						 
						 $arDepth[$arSect["DEPTH_LEVEL"]] = $arSect;
					 }
					 else if(count($arDepth) > $arSect["DEPTH_LEVEL"]-1){
						 
						 for($i=count($arDepth)+1;$i >= $arSect["DEPTH_LEVEL"];$i--){
							 
							 if(isset($arRes[$arDepth[$i]["ID"]])):
							 
							  $tmppath="/";
							  foreach($arDepth as $sectDepth){
								  $tmppath.=$sectDepth["CODE"]."/";
							  }
							  
							   foreach($arRes[$arDepth[$i]["ID"]] as $pageMenu){
								  
								  $arMenu[$tmppath.$pageMenu["CODE"].".php"]=array(
									 "ID" => $pageMenu["ID"],
									 "NAME" => $pageMenu["NAME"],
									 "SORT" => $pageMenu["SORT"],
									 "LINK" => $tmppath.$pageMenu["CODE"].".php",
									 "PAGE" => "Y",
									 "DEPTH_LEVEL" => $arDepth[$i]["DEPTH_LEVEL"],
									 "IS_PARENT" => "N",
								   );
						 
							    }
							  endif;
							 
							 unset($arDepth[$i]);

						 }
						 $arDepth[$arSect["DEPTH_LEVEL"]] = $arSect; 
					 }
					 
					 if(isset($arRes[$arDepth[$arSect["DEPTH_LEVEL"]-1]["ID"]])){
						 
						 $depth = $arDepth[$arSect["DEPTH_LEVEL"]-1]["DEPTH_LEVEL"];
						 
						 foreach($arRes[$arDepth[$arSect["DEPTH_LEVEL"]-1]["ID"]] as $codeElem => $pageMenu){
							 
							 if($pageMenu["SORT"] < $arSect["SORT"]){
								 
							 	  $arMenu[$parentPath.$pageMenu["CODE"].".php"]=array(
									 "ID" => $pageMenu["ID"],
									 "NAME" => $pageMenu["NAME"],
									 "SORT" => $pageMenu["SORT"],
									 "LINK" => $parentPath.$pageMenu["CODE"].".php",
									 "PAGE" => "Y",
									 "DEPTH_LEVEL" => $depth,
									 "IS_PARENT" => "N",
								   );
								   unset($arRes[$arDepth[$arSect["DEPTH_LEVEL"]-1]["ID"]][$codeElem]);
								   
							 }else break;
							 
						 } 
					 }

					  $is_parent="N";
					  if(isset($arRes[$arSect["ID"]]))
						  $is_parent="Y";
					  
					  $arMenu[$parentPath.$arSect["CODE"]."/"]=array(
								 "ID" => $arSect["ID"],
								 "NAME" => $arSect["NAME"],
								 "SORT" => $arSect["SORT"],
								 "LINK" => $parentPath.$arSect["CODE"]."/",
								 "PAGE" => "N",
								 "DEPTH_LEVEL" => $arSect["DEPTH_LEVEL"]-1,
								 "IS_PARENT" => $is_parent,
							   );
							   
					  $before_punkt = $parentPath.$arSect["CODE"]."/";

				  }
				  
				  
				  
				  if(count($arDepth) > 0){
						 
						 for($i=count($arDepth)+1;$i > 0;$i--){
							 
							 if(isset($arRes[$arDepth[$i]["ID"]])):
							 
							  $tmppath="/";
							  foreach($arDepth as $sectDepth){
								  $tmppath.=$sectDepth["CODE"]."/";
							  }
							  
							   foreach($arRes[$arDepth[$i]["ID"]] as $pageMenu){
								  
								  $arMenu[$tmppath.$pageMenu["CODE"].".php"]=array(
									 "ID"   => $pageMenu["ID"],
									 "NAME" => $pageMenu["NAME"],
									 "SORT" => $pageMenu["SORT"],
									 "LINK" => $tmppath.$pageMenu["CODE"].".php",
									 "PAGE" => "Y",
									 "DEPTH_LEVEL" => $arDepth[$i]["DEPTH_LEVEL"],
									 "IS_PARENT" => "N",
								   );
						 
							    }
							  endif;
							 

						 }
					 }
			}
		


			return serialize($arMenu);
			endif;	
		}
		
		
	}