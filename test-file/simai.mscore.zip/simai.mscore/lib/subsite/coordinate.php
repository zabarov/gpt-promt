<?
//only portal
namespace SIMAI\Main\Subsite;

	class Coordinate{  
	  
	   static function GetSettings($redirect="https://02edu.ru/")
	   {
		   
		   	  $_SERVER["SERVER_NAME"] = str_replace("www.", "", $_SERVER["SERVER_NAME"]);
		   
		      if(strpos($_SERVER["SERVER_NAME"],SITE_SERVER_NAME)){
			      $SERVER_NAME=str_replace(".".SITE_SERVER_NAME, "", $_SERVER["SERVER_NAME"]);
			
			  } else{
				  $SERVER_NAME=$_SERVER["SERVER_NAME"];
			  }
	
				if($_SESSION["SITE_NAME"]!=$SERVER_NAME && $_SERVER["SERVER_NAME"]!=SITE_SERVER_NAME):
				   if(!self::is_session_started()) session_start();
					self::GetOrgParams($SERVER_NAME,$redirect); 
				
			   endif;	
				
		}
		
		static function GetOrgParams($SERVER_NAME, $redirect)
		{
			if (\CModule::IncludeModule("iblock")):
			
			  
			  //находим домен по домену находим организацию
			 $arSelect = Array("ID", "IBLOCK_ID", "NAME","PROPERTY_*");
			 $arFilter = Array("IBLOCK_ID"=> \COption::GetOptionString("simai.eduportal", "domen_iblock", ""), "ACTIVE" => "Y","NAME" => $SERVER_NAME);

			 $res = \CIBlockElement::GetList(Array("ID"=>"ASC"), $arFilter, false, false, $arSelect);
			 if($ob = $res->GetNextElement()){
				 
                  $arProps = $ob->GetProperties();  
				  if($arProps["ORGANIZATION"]["VALUE"]!=""){
					  
					  //находим инфоблок с организацией
					  $res = \CIBlockElement::GetByID($arProps["ORGANIZATION"]["VALUE"]);
					  if($ar_res = $res->GetNext()){
					     $IBLOCK_ID = $ar_res['IBLOCK_ID'];
						 $ID = $ar_res['ID'];
						 //находим тип организации
						 $arSelect = Array("ID", "IBLOCK_ID", "NAME","PROPERTY_*");
			             $arFilter = Array("IBLOCK_ID"=> \COption::GetOptionString("simai.eduportal", "type_iblock", ""), 
						                   "ACTIVE"=>"Y",
										   "PROPERTY_IBLOCK" => $IBLOCK_ID);

			             $res1 = \CIBlockElement::GetList(Array("ID"=>"ASC"), 
						                                 $arFilter, 
														 false, 
														 false, 
														 $arSelect);
														 
			             if($ob1 = $res1->GetNextElement()){
							$arProps1 = $ob1->GetProperties();
							$_SESSION["ORGANIZATION"]["PATH"] = $arProps1["PATH"]["VALUE"];
						 }
					  }
					  
				  }else{LocalRedirect($redirect);}
				  
			 }else{LocalRedirect($redirect);}
		
			    self::SetParams($IBLOCK_ID,$ID);
				
			else:
				 LocalRedirect($redirect);
			endif;
		  
		}
		
		
		static function GetCashe($domen,$refresh = false)
		{
			
		  $cache_id = "subsite_".$domen; 
		  
		  $obCache = new \CPHPCache; 
		  if($refresh){
			  $life_time = 1;
			  $obCache->InitCache($life_time, $cache_id, "/".$cache_id);
			  $obCache->CleanDir("/".$cache_id);
		  }else{
		      $life_time = 86400;
		  }			  
		 
		  if($obCache->InitCache($life_time, $cache_id,  "/".$cache_id)):
				$vars = $obCache->GetVars();
				return $vars["settings"];
		  else:
			 \CModule::IncludeModule("iblock");
			 $settings=array();
			  //находим домен по домену находим организацию
			 $arSelect = Array("ID", "IBLOCK_ID", "NAME","PROPERTY_*");
			 $arFilter = Array("IBLOCK_ID"=> \COption::GetOptionString("simai.eduportal", "domen_iblock", ""), "ACTIVE"=>"Y", "NAME" => $domen);
			 $res = \CIBlockElement::GetList(Array("ID"=>"ASC"), $arFilter, false, false, $arSelect);
			 if($ob = $res->GetNextElement()){
				 
                  $arProps = $ob->GetProperties();  
				  if($arProps["ORGANIZATION"]["VALUE"]!=""){
					  
					  //находим инфоблок с организацией
					  $res = \CIBlockElement::GetByID($arProps["ORGANIZATION"]["VALUE"]);
					  if($ar_res = $res->GetNext()){
					     $IBLOCK_ID = $ar_res['IBLOCK_ID'];
						 $ID = $ar_res['ID'];
						 
						 
						 $arSelect = Array("ID", "IBLOCK_ID", "NAME","DETAIL_TEXT", "DATE_ACTIVE_FROM","PROPERTY_*");
						 $arFilter = Array("IBLOCK_ID" => $IBLOCK_ID, "ACTIVE"=>"Y","ID" => $ID);
						 $res = \CIBlockElement::GetList(Array(), $arFilter, false, false, $arSelect);
						 if($ob = $res->GetNextElement()){ 
						
							$arFields = $ob->GetFields();	  
							$settings["ID"]=$arFields["ID"];
							$settings["SITE_STRUCTURE"] = unserialize($arFields["~DETAIL_TEXT"]);
							$arProps = $ob->GetProperties();
							
							foreach($arProps as $code => $prop){
								
								//if($code == "STATUS") continue;
									if(isset($prop["VALUE_XML_ID"])){$settings[$code] = $prop["VALUE_XML_ID"];}
									else{
										if($prop["PROPERTY_TYPE"]=="F" && $prop["VALUE"]!=""){
										$settings[$code] = \CFile::GetPath($prop["VALUE"]);
										}
									else{

										if($prop["PROPERTY_TYPE"]=="G" && $prop["VALUE"]==""){

											if(intval($prop["LINK_IBLOCK_ID"])){
																		
												$rsSections = \CIBlockSection::GetList(array(), array("IBLOCK_ID" => $prop["LINK_IBLOCK_ID"], "SECTION_ID" => false, "NAME" => $ID),false, array("ID", "IBLOCK_ID", "IBLOCK_SECTION_ID", "NAME"));
												if ($arSection = $rsSections->Fetch()){
													\CIBlockElement::SetPropertyValueCode($ID, $code, $arSection["ID"]);
													$settings[$code] = $arSection["ID"];
												}
											}

										}else{
											$settings[$code] = $prop["VALUE"];
										}
									}
								}
								}
						  }
						 
						 //находим тип организации
						 $arSelect = Array("ID", "IBLOCK_ID", "NAME","DETAIL_TEXT","PROPERTY_*");
			             $arFilter = Array("IBLOCK_ID"=> \COption::GetOptionString("simai.eduportal", "type_iblock", ""), 
						                   "ACTIVE"=>"Y",
										   "PROPERTY_IBLOCK" => $IBLOCK_ID);

			             $res1 = \CIBlockElement::GetList(Array("ID"=>"ASC"), $arFilter, false, false,$arSelect);
														 
			             if($ob1 = $res1->GetNextElement()){
							$arProps1 = $ob1->GetProperties();
							$settings["PATH"] = $arProps1["PATH"]["VALUE"];
							$settings["HIGHLOADBLOCK"] = $arProps1["HIGHLOADBLOCK"]["VALUE"];
							$settings["TYPE"] = $arProps1["TYPE"]["VALUE"];
							
						 }
					  }  
				  } 
			 }
		    if($obCache->StartDataCache()):

				$obCache->EndDataCache(array(
					"settings" => $settings
					)); 
		   endif;
		   return $settings;
         endif;
		  
		}
				
		static function SetParams($IBLOCK_ID,$ID)
		{
				if (\CModule::IncludeModule("iblock")):
				
					  //находим инфоблок с организацией
					  
					 	$arSelect = Array("ID", "IBLOCK_ID", "NAME","DETAIL_TEXT", "DATE_ACTIVE_FROM","PROPERTY_*");
						$arFilter = Array("IBLOCK_ID" => $IBLOCK_ID, "ACTIVE"=>"Y","ID" => $ID);
						$res = \CIBlockElement::GetList(Array(), $arFilter, false, false, $arSelect);
						if($ob = $res->GetNextElement()){ 
						
							$arFields = $ob->GetFields();	  
							$_SESSION["ORGANIZATION"]["ID"]=$arFields["ID"];
							$_SESSION["ORGANIZATION"]["SITE_STRUCTURE"] = unserialize($arFields["~DETAIL_TEXT"]);
							$arProps = $ob->GetProperties();
							
							foreach($arProps as $code => $prop){
								
								if($code == "STATUS") continue;
								if(isset($prop["VALUE_XML_ID"])){$_SESSION["ORGANIZATION"][$code] = $prop["VALUE_XML_ID"];}
								else{
									 if($prop["PROPERTY_TYPE"]=="F" && $prop["VALUE"]!=""){
										$_SESSION["ORGANIZATION"][$code] = \CFile::GetPath($prop["VALUE"]);
									 }
									 else{
										     $_SESSION["ORGANIZATION"][$code] = $prop["VALUE"];
									 }
									}
								}
								
								//self::checkBase();
							}
							
			    endif;		  
		}
		
		static function CreateSection($IBLOCK_ID,$NAME){
			
			if (\CModule::IncludeModule("iblock")):
			    
				$bs = new \CIBlockSection;
				$arFields = Array(
				  "IBLOCK_SECTION_ID" => false,
				  "IBLOCK_ID" => $IBLOCK_ID,
				  "NAME" => $NAME,
				  );
              $ID = $bs->Add($arFields);
			  return $ID;
			 endif;	
		}
		
		
		static function checkBase()
		{
				if (\CModule::IncludeModule("iblock")):
			
			
				    $struct = require $_SERVER["DOCUMENT_ROOT"].$_SESSION["ORGANIZATION"]["PATH"].".params/.site.structure.php";

					$res = \CIBlockSection::GetByID($_SESSION["ORGANIZATION"]["STATIC_PAGE"]);
					if($ar_res = $res->GetNext())
						$IBLOCK_ID = $ar_res["IBLOCK_ID"];
					
					$exist_change=false;
					foreach($struct as $item){
						
						if($item["type"] == "page" && $item["section"] == "") continue;
						
						$code="/".$item["path"];
						
						if($item["type"] == "page")
							$code=$code.".php";
						else
							$code=$code."/";
						
						if(isset($_SESSION["ORGANIZATION"]["SITE_STRUCTURE"][$code])){
							
							if($_SESSION["ORGANIZATION"]["SITE_STRUCTURE"][$code]["NAME"] != $item["name"] || $_SESSION["ORGANIZATION"]["SITE_STRUCTURE"][$code]["SORT"] != $item["sort"]){

							
								if($_SESSION["ORGANIZATION"]["SITE_STRUCTURE"][$code]["PAGE"] == "N"):
								
									$bs = new \CIBlockSection;
									$arUpdate = Array("NAME" => $item["name"],"SORT" => $item["sort"]);
									$res = $bs->Update($_SESSION["ORGANIZATION"]["SITE_STRUCTURE"][$code]["ID"], $arUpdate);
									
	
							
								   
								else:
									
									$el = new \CIBlockElement;
									$arUpdate = Array("NAME" => $item["name"],"SORT" => $item["sort"]);
									$res = $el->Update($_SESSION["ORGANIZATION"]["SITE_STRUCTURE"][$code]["ID"], $arUpdate);
									
								
								endif;	
								
								$exist_change=true;
							}

						}else{
							$section = $_SESSION["ORGANIZATION"]["STATIC_PAGE"];
							
							if($item["section"]!="")
								$section = $_SESSION["ORGANIZATION"]["SITE_STRUCTURE"]["/".$item["section"]."/"]["ID"];
							
							$bs = new \CIBlockSection;
							$arUpdate = Array(
							  "IBLOCK_SECTION_ID" => $section,
							  "CODE" => $item["code"],
							  "IBLOCK_ID" => $IBLOCK_ID,
							  "NAME" => $item["name"],
							  "SORT" => $item["sort"],
							  "UF_BASE" => 1,
							  );
	
							$ID = $bs->Add($arUpdate);
						
	 
					  	    $_SESSION["ORGANIZATION"]["SITE_STRUCTURE"]["/".$item["section"]."/".$item["code"]."/"] = array("ID" => $ID,"name" => $item["name"]);
							$exist_change=true;
						}
					}
					
					if($exist_change):
					
						$tree_content = \SIMAI\Main\Subsite\Tree::Get($_SESSION["ORGANIZATION"]["STATIC_PAGE"]);
	                    $_SESSION["ORGANIZATION"]["SITE_STRUCTURE"] = unserialize($tree_content);
						$el = new \CIBlockElement;
						$arLoadProductArray = Array(
							  "DETAIL_TEXT"    => $tree_content,
						);
						$el->Update($_SESSION["ORGANIZATION"]["ID"], $arLoadProductArray);
						
					endif;	
			
			    endif;	
		}
		
		
		
		
		
		  static function is_session_started()
			{
			  if ( version_compare(phpversion(), '5.4.0', '>=') ) {
					return session_status() === PHP_SESSION_ACTIVE ? TRUE : FALSE;
				} else {
					return session_id() === '' ? FALSE : TRUE;
				}
			}
	}