<?
// IO class for SIMAI Framework

namespace SIMAI\Main\IO;

class IncludeArea
{	
	static function getFilePath($fileName, $startPath)
	{
		
	  if($startPath=="/") return false;
	  if(substr($startPath, -1)!="/") $startPath.="/";
	  if(file_exists($startPath.$fileName)) return $startPath.$fileName;
	  else{
		   if($startPath==str_replace("simai.data", "", SF_SITE_PATH))return false;
		   return self::getFilePath($fileName, dirname($startPath)); 
	  }
	}
	
	static function includeSectionArea($filePrefix)
	{
	 global $APPLICATION;
	 $dir = \SIMAI\Main\Configuration\Property::getValue(SF_SITE_DIR, "path");
	  if($_SERVER["SERVER_NAME"]!=SITE_SERVER_NAME)
	    $path = self::getFilePath("section.".$filePrefix.".php", $_SERVER["DOCUMENT_ROOT"].$dir.strtok($_SERVER["REQUEST_URI"], '?'));
       else
	    $path = self::getFilePath("section.".$filePrefix.".php", $_SERVER["DOCUMENT_ROOT"].strtok($_SERVER["REQUEST_URI"],'?'));
	 
	 if($path) require $path;
	 else return false;
	}
	
	static function includeFileArea($filePrefix)
	{
	 global $APPLICATION;
	 
	 if($_SERVER["SERVER_NAME"]==SITE_SERVER_NAME)
		 $fileName = str_replace(".php",".".$filePrefix.".php",$_SERVER["PHP_SELF"]); 
     else
     $fileName = str_replace(".php",".".$filePrefix.".php",$_SERVER["PHP_SELF"]); 
	 if(file_exists($_SERVER["DOCUMENT_ROOT"].$fileName))
		        require $_SERVER["DOCUMENT_ROOT"].$fileName;
	 else return false;
	}
	
	static function includeTemplateArea($dirName)
	{
	 global $APPLICATION;
     $fileName = SF_DATA_DIR."/template/area/".$dirName."/template.php"; 
	 if(file_exists($_SERVER["DOCUMENT_ROOT"].$fileName))
		        require $_SERVER["DOCUMENT_ROOT"].$fileName;
	 else return false;
	}
	
}

?>