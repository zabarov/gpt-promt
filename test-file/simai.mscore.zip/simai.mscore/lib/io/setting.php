<?
// IO class for SIMAI Framework

namespace SIMAI\Main\IO;

class Setting
{	
	static function saveToFile($array, $filename)
	{
		$textArray = '<? return ';
		$textArray .= var_export($array, true);
		$textArray .= '?>';
		file_put_contents($filename, $textArray);
	}
	
	static function getFromFile($filename)
	{
		require $filename;
		$nameArray='ar'.ucfirst(str_replace(".", "", basename($filename, ".php")));
		return ${$nameArray};
	}
}

?>