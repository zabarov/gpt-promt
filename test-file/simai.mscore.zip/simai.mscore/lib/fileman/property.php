<?
// Fileman for SIMAI Framework

namespace SIMAI\Main\Fileman;


class Property {
	
	static function SetPageTitle($prolog, $title){
	
	if(preg_match('/
		(\$APPLICATION->SetTitle\()
		(
			"[^"\\\\]*(?:\\\\.[^"\\\\]*)*"                           # match double quoted string
			|
			\'[^\'\\\\]*(?:\\\\.[^\'\\\\]*)*\'                       # match single quoted string
		)
		(\);)
		/ix', $prolog, $regs)
	)
	{
		$prolog = str_replace($regs[0], $regs[1]."\"".EscapePHPString($title)."\");", $prolog);
	}
	else
	{
		$p = strpos($prolog, "prolog_before");
		if($p===false)
			$p = strpos($prolog, "prolog.php");
		if($p===false)
			$p = strpos($prolog, "header.php");

		if($p===false)
		{
			if(strlen($title)<=0)
				$prolog = preg_replace("#<title>[^<]*</title>#i", "", $prolog);
			elseif(preg_match("#<title>[^<]*</title>#i", $prolog))
				$prolog = preg_replace("#<title>[^<]*</title>#i", "<title>".$title."</title>", $prolog);
			else
				$prolog = $prolog."\n<title>".htmlspecialcharsbx($title)."</title>\n";
		}
		else
		{
			$p = strpos(substr($prolog, $p), ")") + $p;
			$prolog = substr($prolog, 0, $p+1).";\n\$APPLICATION->SetTitle(\"".EscapePHPString($title)."\")".substr($prolog, $p+1);
		}
	}
	return $prolog;
}
    
	static function SetProperty($prolog, $property_key, $property_val){
	
		if(preg_match("'(\\\$APPLICATION->SetPageProperty\\(\"".preg_quote(EscapePHPString($property_key), "'")."\" *, *)([\"\\'])(.*?)(?<!\\\\)([\"\\'])(\\);[\r\n]*)'i", $prolog, $regs)
			|| preg_match("'(\\\$APPLICATION->SetPageProperty\\(\\'".preg_quote(EscapePHPString($property_key, "'"), "'")."\\' *, *)([\"\\'])(.*?)(?<!\\\\)([\"\\'])(\\);[\r\n]*)'i", $prolog, $regs))
		{
			if (strlen($property_val)<=0)
				$prolog = str_replace($regs[1].$regs[2].$regs[3].$regs[4].$regs[5], "", $prolog);
			else
				$prolog = str_replace($regs[1].$regs[2].$regs[3].$regs[4].$regs[5], $regs[1].$regs[2].EscapePHPString($property_val, $regs[2]).$regs[4].$regs[5], $prolog);
		}
		else
		{
			if (strlen($property_val)>0)
			{
				$p = strpos($prolog, "prolog_before");
				if($p===false)
					$p = strpos($prolog, "prolog.php");
				if($p===false)
					$p = strpos($prolog, "header.php");
				if($p!==false)
				{
					$p = strpos(substr($prolog, $p), ")") + $p;
					$prolog = substr($prolog, 0, $p+1).";\n\$APPLICATION->SetPageProperty(\"".EscapePHPString($property_key)."\", \"".EscapePHPString($property_val)."\")".substr($prolog, $p+1);
				}
			}
		}
		return $prolog;
    }

	static function GetPageProps($filename){
		$file=file_get_contents($filename);
		preg_match_all('/APPLICATION->SetPageProperty[^)]{3,}/',
		$file, 
		$matches, 
		PREG_OFFSET_CAPTURE);
		$properties=array();
		foreach($matches[0] as $match){
			
			$start_pos=strpos($match[0],"(")+1;
			$end_pos=strpos($match[0],",")-1;
			$name=substr($match[0],$start_pos,$end_pos - $start_pos);
			$start_pos=strpos($match[0],",")+1;
			$value=substr($match[0],$start_pos, -1);
			$value=str_replace(array("'",'"'), "", $value);
			$name=str_replace(array("'",'"'), "", $name);
			$properties[$name] = trim($value);
		}
		return $properties;
	}

	static function GetPageTitle($filename){
		$file=file_get_contents($filename);
		preg_match('/APPLICATION->SetTitle[^)]{3,}/',
				   $file,
				   $matches, 
				   PREG_OFFSET_CAPTURE);
		$start_pos=strpos($matches[0][0],"(")+2;
		return substr($matches[0][0],$start_pos, -1);
	}
	
	// get dir property for ajax windows
	function getDirProperty($property){
		$path=GetDirPath(GetPagePath($_SERVER["HTTP_REFERER"]));
		global $APPLICATION;
		$props = $APPLICATION->GetDirPropertyList(str_replace($_SERVER["SERVER_NAME"],"", substr($path,strpos($path, $_SERVER["SERVER_NAME"]))));
		return  $props[strtoupper($property)];
	}	
	
}

?>