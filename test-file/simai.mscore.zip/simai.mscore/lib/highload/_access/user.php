<?

namespace SIMAI\Highload\Access;
use Bitrix\Highloadblock\HighloadBlockTable as HLBT;

class User
{
    public static $hl_code = "CSIUsers";
    public static $group_id = "21";

    public static function getGroups($bx_user, $options = false)
    {
        $result=array();
        $groups = \CUser::GetUserGroup($bx_user);
        $filter = array("ID"=>implode('|',$groups));
        $rsGroups = \CGroup::GetList(($by="c_sort"), ($order="desc"), $filter);
        while($f = $rsGroups->Fetch())
        {
            if($options !== false)
            {
                $result[] = $f[$options];
            }
            else
            {
                $result[] = $f;
            }
        }
        return $result;
    }

    public static function getHlUser($bx_user)
    {
        if(empty($bx_user)) return false;
        $hl_id = \SIMAI\Highload::getEntityId(self::$hl_code);

        $hlblock = HLBT::getById($hl_id)->fetch();
        $entity = HLBT::compileEntity($hlblock);
        $entity_data_class = $entity->getDataClass();
        $rsData = $entity_data_class::getList(array(
            'order' => array('ID'=>'ASC'),
            'select' => array('*'),
            'filter' => array('UF_CSI_USER__COWORKER' => $bx_user)
        ));
        if($el = $rsData->fetch())
        {
            return $el['ID'];
        }
        else
            return false;
        
    }

    public static function create($name, $email)
    {
        $rsGroups = \CGroup::GetList(
            ($by="c_sort"),
            ($order="desc"),
            array("STRING_ID"=>"Nakaz")
        );
        if($f = $rsGroups->Fetch())
        {
            $nakaz = $f;
        }
        \Bitrix\Main\Loader::includeSharewareModule("main");
        $p = self::generatePassword();
        $user = new \CUser;
        $arFields = Array(
            'NAME' => $name,
            'EMAIL' => $email,
            'LOGIN' => $email,
            'PASSWORD' => $p,
            'CONFIRM_PASSWORD' => $p,
            'GROUP_ID' => array($nakaz['ID'])
        );
        $newUserId = $user->Add($arFields);
        
        $arEventFields = array(
            'LOGIN' => $fields['PROPERTY_EMAIL_VALUE'],
            'PASSWORD' => $p,
            'EMAIL_TO' => $fields['PROPERTY_EMAIL_VALUE'],
        );
        //\CEvent::Send("NAKAZ_CONFIRMATION_RESPONSIBLE", 'nk', $arEventFields);
        
        return $newUserId;
    }

    public static function generatePassword($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
}