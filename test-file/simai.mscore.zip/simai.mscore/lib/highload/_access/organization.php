<?

namespace SIMAI\Highload\Access;
use Bitrix\Highloadblock\HighloadBlockTable as HLBT;

class Organization
{

    // static variables of highload codes, id, field names
    public static $hl_code = "CSIOrganizations";
    public static $uf_parent = "UF_CSI_ORGANIZATION__PARENT_ORGANIZATION";
    public static $hl_code_access = "CSIAccess";
    public static $uf_add_task = "UF_CSI_ACCESS__ADD_TASK";

    /**
     * 
     * Gets organizations and suborganizations where current user is responsible
     * @param array $hl_user - highload user
     * @param bool $child - get child organizations
     * @return array $arResult - organizations list where user is responsible
     */
    public static function getByUser($hl_user, $child=true)
    {
        if(empty($hl_user)) return false;
        $hl_id = \SIMAI\Highload::getEntityId(self::$hl_code);
        // request to highload table
        $hlblock = HLBT::getById($hl_id)->fetch();
        $entity = HLBT::compileEntity($hlblock);
        $entity_data_class = $entity->getDataClass();
        $rsData = $entity_data_class::getList(array(
            'order' => array('ID'=>'ASC'),
            'select' => array('*'),
            'filter' => array('UF_CSI_ORGANIZATION__RESPONSIBLE'=>$hl_user)
        ));
        // get result
        while($el = $rsData->fetch())
        {
            $arOrg[] = $el['ID'];
        }
 
        // getting child organizations
        if($child==true)
        {
            $arResult = self::getChild($arOrg);
        }
        else
        {
            $arResult = $arOrg;
        }
        

        return $arResult;        
    }

    /**
     * 
     * Gets parents id by array of child id
     * @param array $arOrg
     * @return array $arResult - parents id of $arOrg
     */
    public static function getParents($arOrg)
    {
        if($arOrg === false) return false;

        $arResult = $arParent = $arOrg;
        $hl_id = \SIMAI\Highload::getEntityId(self::$hl_code);

        $i = 0;
        while($i < 10) // db requests limitation
        {
            $hl_results = \SIMAI\Highload\Element\HLBlock::getArrayById($hl_id,$arParent);
            $next = false; $arParent = array();
            foreach($hl_results as $hl_result)
            {
                $parent = $hl_result[self::$uf_parent];
                if (!in_array($parent, $arResult) && !empty($parent))
                {
                    $arParent[] = $parent;
                    $arResult[] = $parent;
                    $next = true;
                }
            }
            if ($next == false)
                break;
            
            $i++;
        }

        return array_unique($arResult);
    }

    /**
     * 
     * Gets parents id by array of child id
     * @param array $arOrg
     * @return array $arResult - parents id of $arOrg
     */
    public static function getChild($arOrg)
    {
        if($arOrg === false) return false;

        $arResult = $arParent = $arOrg;
        $hl_id = \SIMAI\Highload::getEntityId(self::$hl_code);

        $i = 0;
        while($i < 10) // db requests limitation
        {
            // request to highload table
            $hl_results = array();
            $hlblock = HLBT::getById($hl_id)->fetch();
            $entity = HLBT::compileEntity($hlblock);
            $entity_data_class = $entity->getDataClass();
            $rsData = $entity_data_class::getList(array(
                'order' => array('ID'=>'ASC'),
                'select' => array('*'),
                'filter' => array(self::$uf_parent => $arParent)
            ));
            $next = false; $arParent = array();
            // get result
            $hl_results = $rsData->fetchAll();

            // get only parents id and decide to next request
            foreach($hl_results as $hl_result)
            {
                $parent = $hl_result['ID'];
                if (!in_array($parent, $arResult) && !empty($parent))
                {
                    $arParent[] = $parent;
                    $arResult[] = $parent;
                    $next = true;
                }
            }

            if ($next == false) break;

            $i++;
        }

        return array_unique($arResult);
    }

    public static function addOrg($hl_user)
    {
        $hl_id = \SIMAI\Highload::getEntityId(self::$hl_code_access);

        // get enums
        $fields = $GLOBALS['USER_FIELD_MANAGER']->GetUserFields('HLBLOCK_'.$hl_id, 0, LANGUAGE_ID);
        foreach($fields as $field)
        {
            if($field['USER_TYPE_ID']=='enumeration')
            {
                $rsEnum = \CUserFieldEnum::GetList(array(), array("USER_FIELD_ID"=>$field['ID']));
                while($el = $rsEnum->Fetch())
                    $arEnum[$field['FIELD_NAME']][$el["VALUE"]] = $el["ID"];
            }
        }

        // request to highload table
        $hlblock = HLBT::getById($hl_id)->fetch();
        $entity = HLBT::compileEntity($hlblock);
        $entity_data_class = $entity->getDataClass();
        $rsData = $entity_data_class::getList(array(
            'order' => array('ID'=>'ASC'),
            'select' => array('*'),
            'filter' => array(
                'LOGIC'=> 'OR',
                array(
                    '=UF_CSI_ACCESS__USER' => $hl_user,
                    '=UF_CSI_ACCESS__ADD_ORG'=>$arEnum['UF_CSI_ACCESS__ADD_ORG']['Y'],
                ),
                array(
                    '=UF_CSI_ACCESS__USER' => $hl_user,
                    '=UF_CSI_ACCESS__ALL_RIGHTS'=>$arEnum['UF_CSI_ACCESS__ALL_RIGHTS']['Y']
                ), 
            )
        ));

        // get result
        while($el = $rsData->fetch())
        {
            $result[] = $el['UF_CSI_ACCESS__ORGANIZATION'];
        }

		return $result;
    }


    /**
     * 
     * Getting the organizations list 
     * Which user able to add tasks
     * @param array $hl_user - highload user
     * @return array $result - organizations id array
     */
    public static function addTask($hl_user)
    {
        $hl_id = \SIMAI\Highload::getEntityId(self::$hl_code_access);

        // get enums
        $fields = $GLOBALS['USER_FIELD_MANAGER']->GetUserFields('HLBLOCK_'.$hl_id, 0, LANGUAGE_ID);
        foreach($fields as $field)
        {
            if($field['USER_TYPE_ID']=='enumeration')
            {
                $rsEnum = \CUserFieldEnum::GetList(array(), array("USER_FIELD_ID"=>$field['ID']));
                while($el = $rsEnum->Fetch())
                    $arEnum[$field['FIELD_NAME']][$el["VALUE"]] = $el["ID"];
            }
        }

        // request to highload table
        $hlblock = HLBT::getById($hl_id)->fetch();
        $entity = HLBT::compileEntity($hlblock);
        $entity_data_class = $entity->getDataClass();
        $rsData = $entity_data_class::getList(array(
            'order' => array('ID'=>'ASC'),
            'select' => array('*'),
            'filter' => array(
                'LOGIC'=> 'OR',
                array(
                    '=UF_CSI_ACCESS__USER' => $hl_user,
                    '=UF_CSI_ACCESS__ADD_TASK'=>$arEnum['UF_CSI_ACCESS__ADD_TASK']['Y'],
                ),
                array(
                    '=UF_CSI_ACCESS__USER' => $hl_user,
                    '=UF_CSI_ACCESS__ALL_RIGHTS'=>$arEnum['UF_CSI_ACCESS__ALL_RIGHTS']['Y']
                ), 
            )
        ));

        // get result
        while($el = $rsData->fetch())
        {
            $result[] = $el['UF_CSI_ACCESS__ORGANIZATION'];
        }

		return $result;
	}

}