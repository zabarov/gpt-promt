<?
//only portal
namespace SIMAI\Highload;

class Search
{  
  public static function OnSearchReindex($NS=Array(), $oCallback=NULL, $callback_method="")
  {

     if(file_exists($_SERVER["DOCUMENT_ROOT"].'/simai/config/.highload.config.php'))
         $config = require $_SERVER["DOCUMENT_ROOT"].'/simai/config/.highload.config.php';
	 else
		 return false;
	 
	 
	 $sortConfig = array();
	 foreach($config as $item){
		 $sortConfig[$item["ID"]] = $item;
	 }
	 
	 ksort($sortConfig);
	 $arResult = array();
	
	global $DB;
	if(!empty($NS["ID"])){
		
		$arId = explode("/", $NS["ID"]);
		$hblId = $arId[0];
		$lastId = $arId[1];
	}
	
	if($NS["MODULE"]=="simai.mscore" && intval($lastId))
		$strWhere = "WHERE ID > ".$lastId;
	else
		$strWhere = "";	
	 
	 
	 
	 
	 foreach($sortConfig as $idHbldConf => $configHighload){
		 
		 
		 if(isset($hblId)){
			 
			 if($hblId > $idHbldConf) continue;
			 if($hblId < $idHbldConf) $strWhere = "";
		 }

	
		//определить поля для индексации
		$searchFields = array();
		$rsData = \CUserTypeEntity::GetList(array(), array("ENTITY_ID" => "HLBLOCK_".$configHighload["ID"]));
		while($arRes = $rsData->Fetch())
		{
			if($arRes["IS_SEARCHABLE"] == "Y" && $arRes["FIELD_NAME"] != $configHighload["TITLE"]){
				
				$searchFields[] = $arRes["FIELD_NAME"];
			}
		}

		
		$strSql = "SELECT * FROM ".$configHighload["TABLE"]." ".$strWhere." ORDER BY ID";
		
		
		 if($DB->type=="MYSQL"){
						$limit = 1000;
						$strSql .= " LIMIT ".$limit;
		 }else{
				$limit = false;
		 }
		 
		
		$db_res = $DB->Query($strSql);
		while ($res = $db_res->Fetch())
		{
		
			$url = "=ID=".$res["ID"]."&CODE=".$res[$configHighload["ELEMENT_CODE"]]."&SECTION_ID=".$res[$configHighload["SECTION"]]."&HLBLOCK=".$configHighload["ID"];
			
			
			//заполнить message
			$message = "";
			foreach($searchFields as $field){
				
				if(!empty($res[$field]) && $field != $configHighload["TITLE"]){
					$message .= str_replace("&nbsp;"," ",strip_tags(htmlspecialchars_decode($res[$field])))."\r\n";
				}
			}
			
			$Result = array(
				"ID" => $configHighload["ID"]."/".$res["ID"],
				"SITE_ID" => $configHighload["SITE"],
				"DATE_CHANGE" => date("d.m.Y H:i", strtotime($res[$configHighload["DATE_CHANGE"]])),
				"URL" => $url,
				"PERMISSIONS" => array(2),
				"TITLE" => $res[$configHighload["TITLE"]],
				"BODY" => $message,
				"PARAM1" => $configHighload["ID"],
				"PARAM2" => $res[$configHighload["PARAM2"]]
			);
			
			if($oCallback){
				
				$res1 = call_user_func(array($oCallback, $callback_method), $Result);
				if(!$res1)
					  return $configHighload["ID"]."/".$res["ID"];
				
			} 
			else $arResult[] = $Result;
			
			if($limit !== false){
				 $limit--;
				 if($limit <= 0)
					 return $configHighload["ID"]."/".$res["ID"];
			 }		
		}
	 }
	
	if($oCallback) return false;
		
	return $arResult;
	
  }

  public static function OnSearchGetURL($arFields)
  {
	  
	if($arFields["MODULE_ID"] !== "simai.mscore") return $arFields["URL"];
		
	  
    //получить конфиг хайлоадблока
	if(file_exists($_SERVER["DOCUMENT_ROOT"].'/simai/config/.highload.config.php'))
         $config = require $_SERVER["DOCUMENT_ROOT"].'/simai/config/.highload.config.php';
	 else
		 return false;
	
	$arIds = explode("/", $arFields["ITEM_ID"]);
	
	$hbld = $arIds[0];
	$idElem = $arIds[1];
	
	if(!intval($hbld)) return false;
	if(!intval($idElem)) return false;
	
	$confHbld = array();
	foreach($config as $elem){
		
		if($elem["ID"] == $hbld){
			$confHbld = $elem;
			break;
		}
	}
	
	if(empty($confHbld)) return false;
	
	$url = "";
	
	
	//получить данные элемента (сделать выборку)
	$connection = \Bitrix\Main\Application::getConnection();

	$sql = "SELECT * FROM ".$confHbld["TABLE"]." where ID='".$idElem."'";

	$recordset = $connection->query($sql);
	if ($record = $recordset->fetch())
	{
		//десериализация
		foreach($record as $key => $val){
			
			if(strpos($val, "a:") === 0){
				$record[$key] = unserialize($val);
			}
		}
		

		$replaces = array();
		
		if(!empty($confHbld["ELEMENT_CODE"]))
		   $replaces["CODE"] = $replaces["ELEMENT_CODE"] = $record[$confHbld["ELEMENT_CODE"]];
	
		$replaces["ID"] = $replaces["ELEMENT_ID"] = $record["ID"];
		
		if(!empty($confHbld["SECTION"])){
		  $replaces["SECTION_ID"] = $record[$confHbld["SECTION"]];
		  $replaces["SECTION_CODE_PATH"] = self::getSectionCodePath($confHbld["TABLE"], $record[$confHbld["SECTION"]], $confHbld["SECTION"], $confHbld["SECTION_CODE"]);
		  $replaces["SECTION_CODE"] = self::getSectionCode($confHbld["TABLE"], $record[$confHbld["SECTION"]], $confHbld["SECTION"]);
		}
		
		//
		$arReplace = array();
		$arSearch = array();
		foreach($replaces as $code => $value){
			
			$arSearch[] = "#".$code."#";
			$arReplace[] = $value;
		}
		
		
		
		$url = str_replace($arSearch, $arReplace, $confHbld["DETAIL_PAGE_URL"]);
	}
	
    return $url;
	
  }
  
  public static function getSectionCode($table, $id, $codeProp)
  {
	
	$connection = \Bitrix\Main\Application::getConnection();
	$sql = "SELECT ID,".$codeProp." FROM ".$table." where ID='".$id."'";
	$recordset = $connection->query($sql);
	if ($record = $recordset->fetch())
	{
		return $record[$codeProp];
	}
	return "";
  }
  
  public static function getSectionCodePath($table, $id, $propSection,$propCode)
  {
	  
	$connection = \Bitrix\Main\Application::getConnection();
	$sql = "SELECT ID,".$propCode.",".$propSection." FROM ".$table." where ID='".$id."'";
	$recordset = $connection->query($sql);
	if ($record = $recordset->fetch())
	{
		if(intval($record[$propSection]))
		   return self::getSectionCodePath($table, $record[$propSection], $propSection, $propCode).($record[$propCode]."/");
	    else
	      return "/".$record[$propCode]."/";
	}
	return "";
  }
  
  public static function updateSearch($id, $hbldName)
  {
	  
	if(!\Bitrix\Main\Loader::includeModule("search")) return;
	
	global $DB;

	//получить конфиг хайлоадблока
	if(file_exists($_SERVER["DOCUMENT_ROOT"].'/simai/config/.highload.config.php')) $config = require $_SERVER["DOCUMENT_ROOT"].'/simai/config/.highload.config.php';
	else return;
	
	if(!isset($config[$hbldName])) return;
	
	$configHighload = $config[$hbldName];
	
	
	//определить поля для индексации
	$searchFields = array();
	$rsData = \CUserTypeEntity::GetList(array(), array("ENTITY_ID" => "HLBLOCK_".$configHighload["ID"]));
	while($arRes = $rsData->Fetch()){
		if($arRes["IS_SEARCHABLE"] == "Y" && $arRes["FIELD_NAME"] != $configHighload["TITLE"]){
				
				$searchFields[] = $arRes["FIELD_NAME"];
		}
	}
		
		
	//получаем 
	$strSql = "SELECT * FROM ".$configHighload["TABLE"]." WHERE ID=".intval($id);
	$db_res = $DB->Query($strSql);
	$res = $db_res->Fetch();
		
		
	
	$url = "=ID=".$id."&CODE=".$res[$configHighload["ELEMENT_CODE"]]."&SECTION_ID=".$res[$configHighload["SECTION"]]."&HLBLOCK=".$configHighload["ID"];
			
			
	//заполнить message
	$message = "";
	foreach($searchFields as $field){
				
	    if(!empty($res[$field]) && $field != $configHighload["TITLE"]){
					$message .= str_replace("&nbsp;"," ",strip_tags(htmlspecialchars_decode($res[$field])))."\r\n";
		}
	}
	
	$ID_SEARCH_ELEM = $configHighload["ID"]."/".$id;
	$Result = array(
				"SITE_ID" => $configHighload["SITE"],
				"LAST_MODIFIED" => date("d.m.Y H:i", strtotime($res[$configHighload["DATE_CHANGE"]])),
				"URL" => $url,
				"PERMISSIONS" => array(2),
				"TITLE" => $res[$configHighload["TITLE"]],
				"BODY" => $message,
				"PARAM1" => $configHighload["ID"],
				"PARAM2" => $res[$configHighload["PARAM2"]]
	);


	\CSearch::Index("simai.mscore", $ID_SEARCH_ELEM, $Result, true);
	 


  }
  
  
  
}