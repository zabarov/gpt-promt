<?
// SIMAI Framework
// @copyright © SIMAI Studio 2018
// @version 4.0.0
 
namespace SIMAI\Main\Block;

use SIMAI\Main\Configuration\Property;

// Class for edit and add block elements
class Edit {
	
	
	public static function addEditTag2Area($idItem,$idForm,$iblock,$idPage)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");
			

			$html = '<style>.z-index-999{z-index: 999 !important;}
			         .sf-nav-fixed {z-index: 998 !important;}</style>
					 
			 <div data-iblock-edit-item data-item-id = "'.$idItem.'" class="position-absolute w-100 h-100"  style="top:0; left:0; z-index: 120">
				<div class="position-relative w-100 h-100 sf-viewbox-wrap">
					<div class="sf-viewbox sf-viewbox-hover bg-grey-800"></div>
					<div class="sf-viewbox sf-viewbox-hover theme-light">
						<div class="c-white">
							<a class="btn btn-primary btn-outline btn-icon btn-1" title="Изменить" href="#" sf-modal="" sf-overlay-modifier="sf-modal-overlay z-index-999" sf-content-modifier="p-0 h-100 d-flex align-items-start" sf-src="/simai.data/admin/edit_tag2.php?id='.$idItem.'&idForm='.$idForm.'&iblock='.$iblock.'&idPage='.$idPage.'" sf-close-modifier="sf-close-left t-3 theme-dark" sf-modal-modifier="fixed-right w-md-50"><i class="fas fa-pen" aria-hidden="true"></i></a>
					</div>
					</div>
				</div>
			 </div>
		
			';
			return $html;
		}
		else
			return false;
	}
	
	public static function editTagArea($idForm, $title="", $edit = 'Y')
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");
			
			
			if(empty($title)){
				$text = '<i class="fas fa-plus" aria-hidden="true"></i>';
				$class = "btn-icon btn-1";
			}
			else{
			    $text = $title;
				$class = "t--1";
			}				
			
		    if($edit == 'Y'){
				
			$html = '<style>.z-index-999{z-index: 999 !important;}
			         .sf-nav-fixed {z-index: 998 !important;}</style>
					 
			 <div data-iblock-edit-item class="position-absolute w-100 h-100"  style="top:0; left:0; z-index: 120">
				<div class="position-relative w-100 h-100 sf-viewbox-wrap">
					<div class="sf-viewbox sf-viewbox-hover bg-grey-800"></div>
					<div class="sf-viewbox sf-viewbox-hover theme-light">
						<div class="c-white">
							<a class="btn btn-primary btn-outline btn-icon btn-1" 
							   title="Изменить" 
							   href="#" 
							   sf-modal="" 
							   sf-overlay-modifier="sf-modal-overlay z-index-999" 
							   sf-content-modifier="p-0 h-100 d-flex align-items-start" 
							   sf-src="/simai.data/admin/edit_tag.php?idForm='.$idForm.'" 
							   sf-close-modifier="sf-close-left t-3 theme-dark" 
							   sf-modal-modifier="fixed-right w-md-50"><i class="fas fa-pen" aria-hidden="true"></i></a>
					  </div>
					</div>
				</div>
			 </div>';
			 
			}else{
				
				$html = '
			    <div data-iblock-new-item class="bg-white b-theme-100 b-1 p-3 t-center">
					<a 
						class="btn btn-primary btn-outline '.$class.'" 
						href="#" 
						sf-modal 
						sf-content-modifier="p-0 h-100" 
						sf-modal-modifier = "fixed-right w-md-50" 
						sf-src="/simai.data/admin/edit_tag.php?idForm='.$idForm.'" 
						sf-close-modifier="sf-close-left t-3 theme-dark"
					>
						'.$title.'
					</a>			
			    </div>';
				
			}
			return $html;
		}
		else
			return false;
	}
	
	public static function deleteEditor($idItem)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			
			$html = '<style>.z-index-999{z-index: 999 !important;}
			         .sf-nav-fixed {z-index: 998 !important;}</style>
			<div data-iblock-edit-item data-item-id = '.$idItem.' class="position-absolute w-100 h-100"  style="top:0; left:0; z-index: 120">
				<div class="position-relative w-100 h-100 sf-viewbox-wrap">
					<div class="sf-viewbox sf-viewbox-hover bg-grey-800"></div>
					<div class="sf-viewbox sf-viewbox-hover light-theme">
						<div class="c-white t-center align-middle">
							<a title="Удалить" href="#" sf-modal sf-modal-modifier = "w-20" sf-src="/simai.data/admin/editor_delete.php?id='.$idItem.'" class="btn btn-primary btn-outline btn-icon btn-1"><i class="fas fa-trash" aria-hidden="true"></i></a>
						</div>
					</div>
				</div>
			</div>
			';
			return $html;
		}
		else
			return false;
	}
	
	public static function addTag2Area($idItem,$idForm,$iblock,$idPage)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			$html = '<style>.z-index-999{z-index: 999 !important;}
			         .sf-nav-fixed {z-index: 998 !important;}</style>
			<div data-iblock-new-item data-iblock-id = '.$idIblock.' class="theme-light p-3 t-center">
				<a title="Изменить" class="btn btn-primary btn-outline btn-icon btn-1" href="#" sf-modal="" sf-overlay-modifier="sf-modal-overlay z-index-999" sf-content-modifier="p-0 h-100 d-flex align-items-start" sf-src="/simai.data/admin/edit_tag2.php?id='.$idItem.'&idForm='.$idForm.'&iblock='.$iblock.'&idPage='.$idPage.'" sf-close-modifier="sf-close-left t-3 theme-dark" sf-modal-modifier="fixed-right w-md-50"><i class="fas fa-pen" aria-hidden="true"></i></a>
			</div>
			';
			return $html;
		}
		else
			return false;
	}

	public static function addTagOneArea($idItem,$idForm,$iblock,$idPage)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			$html = '<style>.z-index-999{z-index: 999 !important;}
			         .sf-nav-fixed {z-index: 998 !important;}</style>
			<div data-iblock-new-item data-iblock-id = '.$idIblock.' class="theme-light p-3 t-center">
				<a title="Изменить" class="btn btn-primary btn-outline btn-icon btn-1" href="#" sf-modal="" sf-overlay-modifier="sf-modal-overlay z-index-999" sf-content-modifier="p-0 h-100 d-flex align-items-start" sf-src="/simai.data/admin/edit_tag_one.php?id='.$idItem.'&idForm='.$idForm.'&iblock='.$iblock.'&idPage='.$idPage.'" sf-close-modifier="sf-close-left t-3 theme-dark" sf-modal-modifier="fixed-right w-md-50"><i class="fas fa-pen" aria-hidden="true"></i></a>
			</div>
			';
			return $html;
		}
		else
			return false;
	}

	
	
	public static function addEditDeArea($idItem,$page)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");
			

			$html = '<style>.z-index-999{z-index: 999 !important;}
			         .sf-nav-fixed {z-index: 98 !important;}</style>
			<div data-iblock-edit-item data-item-id = "'.$idItem.'" class="position-absolute w-100 h-100"  style="top:0; left:0; z-index: 99">
				<div class="position-relative w-100 h-100 sf-viewbox-wrap">
					<div class="sf-viewbox sf-viewbox-hover bg-grey-800"></div>
					<div class="sf-viewbox sf-viewbox-hover theme-light">
						<div class="c-white">
							<a class="btn btn-primary btn-outline btn-icon btn-1" title="Изменить" href="#" sf-modal="" sf-overlay-modifier="sf-modal-overlay z-index-999" sf-content-modifier="p-0 h-100 d-flex align-items-start" sf-src="/simai.data/admin/edit_description.php?id='.$idItem.'&page='.$page.'" sf-close-modifier="sf-close-left t-3 theme-dark" sf-modal-modifier="fixed-right w-md-50"><i class="fas fa-pen" aria-hidden="true"></i></a>
					</div>
					</div>
				</div>
			</div>
			';
			return $html;
		}
		else
			return false;
	}	
	
	
	
	public static function addEmptyEditDeArea($idItem,$page)
	{
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y")
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");

			$html = '<style>.z-index-999{z-index: 999 !important;}
			         .sf-nav-fixed {z-index: 98 !important;}</style>
			<div data-iblock-new-item data-iblock-id = '.$idIblock.' class="theme-light p-3 text-center">
				<a class="btn btn-primary btn-outline btn-icon btn-1" title="Изменить" href="#" sf-modal="" sf-overlay-modifier="sf-modal-overlay z-index-999" sf-content-modifier="p-0 h-100 d-flex align-items-start" sf-src="/simai.data/admin/edit_description.php?id='.$idItem.'&page='.$page.'" sf-close-modifier="sf-close-left t-3 theme-dark" sf-modal-modifier="fixed-right w-md-50"><i class="fas fa-pen" aria-hidden="true"></i></a>
			</div>
			';
			return $html;
		}
		else
			return false;
	}
	

	public static function addConfigurationArea($codeBlock)
	{
		if(Property::getInstance()->get(SF_SITE_DIR, "development_mode") == "Y")
		{
		
			$html = '
			<div class="position-absolute w-100 h-100"  style="top:0; left:0; z-index: 120">
				<div class="position-relative w-100 h-100 sf-viewbox-wrap">
					<div class="sf-viewbox sf-viewbox-hover bg-gray-800"></div>
					<div class="sf-viewbox sf-viewbox-hover theme-dark">
						<div class="c-white t-center align-middle">
						  <a href="#"
						    sf-modal 
	                        sf-content-modifier="p-0 h-100 d-flex align-items-start"
	                        sf-src = "/bitrix/admin/simai/block_property.php" 
	                        sf-close-modifier = "sf-close-left t-3 theme-dark" 
	                        sf-modal-modifier = "fixed-right w-md-50"
						   ><i class="fas fa-cog fa-lg" aria-hidden="true"></i>
						   </a>
						</div>
					</div>
				</div>
			</div>
			';
			return $html;
		}
		else
			return false;
	}

	public static function addNewItemArea($idIblock,$section=false)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");
			
			$resIblock = \CIBlock::GetByID($idIblock);
			if($arIblock = $resIblock->Fetch())
				$typeIblock = $arIblock["IBLOCK_TYPE_ID"];
			
			$new_link = "/bitrix/admin/iblock_element_edit.php?IBLOCK_ID=".$idIblock."&type=".$typeIblock."&ID=0&lang=".SITE_ID."&force_catalog=&filter_section=0&bxpublic=Y&from_module=iblock&return_url=".urlencode($_SERVER["REQUEST_URI"]);
			
			$NEW_BUTTON_ACTION = $GLOBALS['APPLICATION']->getPopupLink(array(
				'URL' => $new_link,
				"PARAMS" => array(900, 600),
			));
			
			$html = '
			<div data-iblock-new-item data-iblock-id = '.$idIblock.' class="bg-white b-theme-100 b-1 p-3 t-center">';
				if(Property::getValue(SF_SITE_DIR, "iblock_public_editor") == "Y")
				{	
					$html .='
					<a 
						class="btn btn-primary btn-outline btn-icon btn-1" 
						href="#" 
						sf-modal 
						sf-content-modifier="p-0 h-100" 
						sf-modal-modifier = "fixed-right w-md-50" 
						sf-src="'.SF_DATA_DIR.'/admin/iblock.element.edit.php?iblock='.$idIblock.'&section='.$section.'" 
						sf-close-modifier="sf-close-left t-3 theme-dark"
					>
						<i class="fas fa-plus" aria-hidden="true"></i>
					</a>';				
				}
				else
				{
					$html .='
					<a class="btn btn-theme btn-icon btn-1" href="javascript:void(0)" onclick="'.$NEW_BUTTON_ACTION.'"><i class="fas fa-plus" aria-hidden="true"></i></a>';
				}
				$html .='			
			</div>
			';
			return $html;
		}
		else
			return false;
	}
	
	public static function addNewSectionArea($idIblock)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			
			$html = '<style>.z-index-999{z-index: 999 !important;}
			         .sf-nav-fixed {z-index: 998 !important;}</style>
			<div data-iblock-new-item data-iblock-id = '.$idIblock.' class="light-theme p-3 t-center">
				<a class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-content-modifier="p-0 h-100" 
									sf-modal-modifier = "fixed-right w-md-80" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.section.edit.php?iblock='.$idIblock.'" 
									sf-close-modifier="sf-close-left t-3 theme-dark" ><i class="fas fa-plus" aria-hidden="true"></i></a>
			</div>
			';
			return $html;
		}
		else
			return false;
	}

	public static function addEditItemArea($idItem,$section=false)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");
			
			$resItem = \CIBlockElement::GetByID($idItem);
			if($arItem = $resItem->Fetch())
				$idIblock = $arItem["IBLOCK_ID"];
			
			$resIblock = \CIBlock::GetByID($idIblock);
			if($arIblock = $resIblock->Fetch())
				$typeIblock = $arIblock["IBLOCK_TYPE_ID"];
			
			$new_link = "/bitrix/admin/iblock_element_edit.php?IBLOCK_ID=".$idIblock."&type=".$typeIblock."&ID=0&lang=".SITE_ID."&force_catalog=&filter_section=0&bxpublic=Y&from_module=iblock&return_url=".urlencode($_SERVER["REQUEST_URI"]);
			
			$edit_link = "/bitrix/admin/iblock_element_edit.php?IBLOCK_ID=".$idIblock."&type=".$typeIblock."&ID=".$idItem."&lang=".SITE_ID."&force_catalog=&filter_section=0&bxpublic=Y&from_module=iblock&return_url=".urlencode($_SERVER["REQUEST_URI"]);

			$NEW_BUTTON_ACTION = $GLOBALS['APPLICATION']->getPopupLink(array(
				'URL' => $new_link,
				"PARAMS" => array(900, 600),
			));
			
			$EDIT_BUTTON_ACTION = $GLOBALS['APPLICATION']->getPopupLink(array(
				'URL' => $edit_link,
				"PARAMS" => array(900, 600),
			));
			
		
			
			$html = '
			<div data-iblock-edit-item data-item-id = '.$idItem.' class="position-absolute w-100 h-100"  style="top:0; left:0; z-index: 120">
				<div class="position-relative w-100 h-100 sf-viewbox-wrap">
					<div class="sf-viewbox sf-viewbox-hover bg-white b-theme-100 b-1 transition"></div>
					<div class="sf-viewbox sf-viewbox-hover theme-light bg-transparent">
						<div class="t-center align-middle">
							<div class="btn-group">';
							if(Property::getValue(SF_SITE_DIR, "edit_mode") == "Y")
							{	
								$html .='
								<a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#"
									sf-modal 
									sf-content-modifier="p-0 h-100" 
									sf-modal-modifier = "fixed-right w-md-80" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.element.edit.php?iblock='.$idIblock.'&section='.$section.'" 
									sf-close-modifier="sf-close-left t-3 theme-dark"
								>
									<i class="fas fa-plus" aria-hidden="true"></i>
								</a>
							    <a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#"
									sf-modal 
									sf-content-modifier="p-0 h-100" 
									sf-modal-modifier = "fixed-right w-md-80" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.element.edit.php?iblock='.$idIblock.'&id='.$idItem.'" 
									sf-close-modifier="sf-close-left t-3 theme-dark"
								>
									<i class="fas fa-pen" aria-hidden="true"></i>
								</a>
								<a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-modal-modifier="w-20" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.element.delete.php?id='.$idItem.'" 
								>
									<i class="fas fa-trash" aria-hidden="true"></i>
								</a>';
							}
							else
							{
								$html .='
								<a class="btn btn-theme btn-icon btn-1" href="javascript:void(0)" onclick="'.$NEW_BUTTON_ACTION.'"><i class="fas fa-plus" aria-hidden="true"></i></a>
								<a class="btn btn-theme btn-icon btn-1" href="javascript:void(0)" onclick="'.$EDIT_BUTTON_ACTION.'"><i class="fas fa-pen" aria-hidden="true"></i></a>
								<a href="#" sf-modal="" sf-modal-modifier="w-20" sf-src="/bitrix/admin/simai/element_delete.php?id='.$idItem.'" class="btn btn-theme btn-icon btn-1"><i class="fas fa-trash" aria-hidden="true"></i></a>';
							}
							$html .='
							</div>
						</div>
					</div>
				</div>
			</div>
			';
			return $html;
		}
		else
			return false;
	}	
	
	public static function tagEditItemArea($idItem,$section=false)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");
			
			$resItem = \CIBlockElement::GetByID($idItem);
			if($arItem = $resItem->Fetch())
				$idIblock = $arItem["IBLOCK_ID"];
			
			$resIblock = \CIBlock::GetByID($idIblock);
			if($arIblock = $resIblock->Fetch())
				$typeIblock = $arIblock["IBLOCK_TYPE_ID"];
			
			$new_link = "/bitrix/admin/iblock_element_edit.php?IBLOCK_ID=".$idIblock."&type=".$typeIblock."&ID=0&lang=".SITE_ID."&force_catalog=&filter_section=0&bxpublic=Y&from_module=iblock&return_url=".urlencode($_SERVER["REQUEST_URI"]);
			
			$edit_link = "/bitrix/admin/iblock_element_edit.php?IBLOCK_ID=".$idIblock."&type=".$typeIblock."&ID=".$idItem."&lang=".SITE_ID."&force_catalog=&filter_section=0&bxpublic=Y&from_module=iblock&return_url=".urlencode($_SERVER["REQUEST_URI"]);

			$NEW_BUTTON_ACTION = $GLOBALS['APPLICATION']->getPopupLink(array(
				'URL' => $new_link,
				"PARAMS" => array(900, 600),
			));
			
			$EDIT_BUTTON_ACTION = $GLOBALS['APPLICATION']->getPopupLink(array(
				'URL' => $edit_link,
				"PARAMS" => array(900, 600),
			));
			
		
			
			$html = '
			<div data-iblock-edit-item data-item-id = '.$idItem.' class="position-absolute w-100 h-100"  style="top:0; left:0; z-index: 120">
				<div class="position-relative w-100 h-100 sf-viewbox-wrap">
					<div class="sf-viewbox sf-viewbox-hover bg-white b-theme-100 b-1 transition"></div>
					<div class="sf-viewbox sf-viewbox-hover theme-light bg-transparent">
						<div class="t-center align-middle">
							<div class="btn-group">';
							if(Property::getValue(SF_SITE_DIR, "edit_mode") == "Y")
							{	
								$html .='
							    <a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-content-modifier="p-0 h-100" 
									sf-modal-modifier = "fixed-right w-md-80" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.element.edit.php?iblock='.$idIblock.'&id='.$idItem.'" 
									sf-close-modifier="sf-close-left t-3 theme-dark"
								>
									<i class="fas fa-pen" aria-hidden="true"></i>
								</a>
								<a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-modal-modifier="w-20" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.element.delete.php?id='.$idItem.'" 
								>
									<i class="fas fa-trash" aria-hidden="true"></i>
								</a>';
							}
							else
							{
								$html .='
								<a class="btn btn-theme btn-icon btn-1" href="javascript:void(0)" onclick="'.$NEW_BUTTON_ACTION.'"><i class="fas fa-plus" aria-hidden="true"></i></a>
								<a class="btn btn-theme btn-icon btn-1" href="javascript:void(0)" onclick="'.$EDIT_BUTTON_ACTION.'"><i class="fas fa-pen" aria-hidden="true"></i></a>
								<a href="#" sf-modal="" sf-modal-modifier="w-20" sf-src="/bitrix/admin/simai/element_delete.php?id='.$idItem.'" class="btn btn-theme btn-icon btn-1"><i class="fas fa-trash" aria-hidden="true"></i></a>';
							}
							$html .='
							</div>
						</div>
					</div>
				</div>
			</div>
			';
			return $html;
		}
		else
			return false;
	}
	
	
	public static function editItemArea($idItem)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");
			
			$resItem = \CIBlockElement::GetByID($idItem);
			if($arItem = $resItem->Fetch())
				$idIblock = $arItem["IBLOCK_ID"];
			
			$resIblock = \CIBlock::GetByID($idIblock);
			if($arIblock = $resIblock->Fetch())
				$typeIblock = $arIblock["IBLOCK_TYPE_ID"];
			
			$new_link = "/bitrix/admin/iblock_element_edit.php?IBLOCK_ID=".$idIblock."&type=".$typeIblock."&ID=0&lang=".SITE_ID."&force_catalog=&filter_section=0&bxpublic=Y&from_module=iblock&return_url=".urlencode($_SERVER["REQUEST_URI"]);
			
			$edit_link = "/bitrix/admin/iblock_element_edit.php?IBLOCK_ID=".$idIblock."&type=".$typeIblock."&ID=".$idItem."&lang=".SITE_ID."&force_catalog=&filter_section=0&bxpublic=Y&from_module=iblock&return_url=".urlencode($_SERVER["REQUEST_URI"]);

			$NEW_BUTTON_ACTION = $GLOBALS['APPLICATION']->getPopupLink(array(
				'URL' => $new_link,
				"PARAMS" => array(900, 600),
			));
			
			$EDIT_BUTTON_ACTION = $GLOBALS['APPLICATION']->getPopupLink(array(
				'URL' => $edit_link,
				"PARAMS" => array(900, 600),
			));
			
		
			
			$html = '
			<div data-iblock-edit-item data-item-id = '.$idItem.' class="position-absolute w-100 h-100"  style="top:0; left:0; z-index: 120">
				<div class="position-relative w-100 h-100 sf-viewbox-wrap">
					<div class="sf-viewbox sf-viewbox-hover bg-white b-theme-100 b-1 transition"></div>
					<div class="sf-viewbox sf-viewbox-hover theme-light bg-transparent">
						<div class="t-center align-middle">
							<div class="btn-group">';
							if(Property::getValue(SF_SITE_DIR, "iblock_public_editor") == "Y")
							{	
								$html .='
							    <a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-content-modifier="p-0 h-100" 
									sf-modal-modifier = "fixed-right w-md-80" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.element.edit.php?iblock='.$idIblock.'&id='.$idItem.'" 
									sf-close-modifier="sf-close-left t-3 theme-dark"
								>
									<i class="fas fa-pen" aria-hidden="true"></i>
								</a>
								<a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-modal-modifier="w-20" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.element.delete.php?id='.$idItem.'" 
								>
									<i class="fas fa-trash" aria-hidden="true"></i>
								</a>';
							}
							else
							{
								$html .='
								<a class="btn btn-theme btn-icon btn-1" href="javascript:void(0)" onclick="'.$NEW_BUTTON_ACTION.'"><i class="fas fa-plus" aria-hidden="true"></i></a>
								<a class="btn btn-theme btn-icon btn-1" href="javascript:void(0)" onclick="'.$EDIT_BUTTON_ACTION.'"><i class="fas fa-pen" aria-hidden="true"></i></a>
								<a href="#" sf-modal="" sf-modal-modifier="w-20" sf-src="/bitrix/admin/simai/element_delete.php?id='.$idItem.'" class="btn btn-theme btn-icon btn-1"><i class="fas fa-trash" aria-hidden="true"></i></a>';
							}
							$html .='
							</div>
						</div>
					</div>
				</div>
			</div>
			';
			return $html;
		}
		else
			return false;
	}
	
	
	public static function addEditSectionArea($idItem)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");
			
			$resItem = \CIBlockSection::GetByID($idItem);
			if($arItem = $resItem->Fetch())
				$idIblock = $arItem["IBLOCK_ID"];
			
			$resIblock = \CIBlock::GetByID($idIblock);
			if($arIblock = $resIblock->Fetch())
				$typeIblock = $arIblock["IBLOCK_TYPE_ID"];
			
	
			
		
			
			$html = '
			<div data-iblock-edit-item data-item-id = '.$idItem.' class="position-absolute w-100 h-100"  style="top:0; left:0; z-index: 120">
				<div class="position-relative w-100 h-100 sf-viewbox-wrap">
					<div class="sf-viewbox sf-viewbox-hover bg-white b-theme-100 b-1 transition"></div>
					<div class="sf-viewbox sf-viewbox-hover theme-light bg-transparent">
						<div class="t-center align-middle">
							<div class="btn-group">';	
								$html .='
								<a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-content-modifier="p-0 h-100" 
									sf-modal-modifier = "fixed-right w-md-80" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.section.edit.php?iblock='.$idIblock.'" 
									sf-close-modifier="sf-close-left t-3 theme-dark"
								>
									<i class="fas fa-plus" aria-hidden="true"></i>
								</a>
							    <a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-content-modifier="p-0 h-100" 
									sf-modal-modifier = "fixed-right w-md-80" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.section.edit.php?iblock='.$idIblock.'&id='.$idItem.'" 
									sf-close-modifier="sf-close-left t-3 theme-dark"
								>
									<i class="fas fa-pen" aria-hidden="true"></i>
								</a>
								<a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-modal-modifier="w-20" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.section.delete.php?id='.$idItem.'" 
								>
									<i class="fas fa-trash" aria-hidden="true"></i>
								</a>';
							
							$html .='
							</div>
						</div>
					</div>
				</div>
			</div>
			';
			return $html;
		}
		else
			return false;
	}
	
	
	
   public static function editSectionArea($idItem)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "edit_mode") == "Y" && $USER->IsAuthorized())
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");
			
			$resItem = \CIBlockSection::GetByID($idItem);
			if($arItem = $resItem->Fetch())
				$idIblock = $arItem["IBLOCK_ID"];
			
			$resIblock = \CIBlock::GetByID($idIblock);
			if($arIblock = $resIblock->Fetch())
				$typeIblock = $arIblock["IBLOCK_TYPE_ID"];
			
	
			
		
			
			$html = '
			<div data-iblock-edit-item data-item-id = '.$idItem.' class="position-absolute w-100 h-100"  style="top:0; left:0; z-index: 120">
				<div class="position-relative w-100 h-100 sf-viewbox-wrap">
					<div class="sf-viewbox sf-viewbox-hover bg-white b-theme-100 b-1 transition"></div>
					<div class="sf-viewbox sf-viewbox-hover theme-light bg-transparent">
						<div class="t-center align-middle">
							<div class="btn-group">';	
								$html .='
							    <a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-content-modifier="p-0 h-100" 
									sf-modal-modifier = "fixed-right w-md-80" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.section.edit.php?iblock='.$idIblock.'&id='.$idItem.'" 
									sf-close-modifier="sf-close-left t-3 theme-dark"
								>
									<i class="fas fa-pen" aria-hidden="true"></i>
								</a>
								<a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-modal-modifier="w-20" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.section.delete.php?id='.$idItem.'" 
								>
									<i class="fas fa-trash" aria-hidden="true"></i>
								</a>';
							
							$html .='
							</div>
						</div>
					</div>
				</div>
			</div>
			';
			return $html;
		}
		else
			return false;
	}
	
	public static function addNewLessonArea($idIblock,$section=false)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "lesson_edit_mode") == "Y" && $USER->IsAuthorized())
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");
			
			$resIblock = \CIBlock::GetByID($idIblock);
			if($arIblock = $resIblock->Fetch())
				$typeIblock = $arIblock["IBLOCK_TYPE_ID"];
			
			$html = '
			<div data-iblock-new-item data-iblock-id = '.$idIblock.' class="bg-white b-theme-100 b-1 p-3 t-center">';
					$html .='
					<a 
						class="btn btn-primary btn-outline btn-icon btn-1" 
						href="#" 
						sf-modal 
						sf-content-modifier="p-0 h-100" 
						sf-modal-modifier = "fixed-right w-md-50" 
						sf-src="'.SF_DATA_DIR.'/admin/iblock.lesson.edit.php?iblock='.$idIblock.'&section='.$section.'" 
						sf-close-modifier="sf-close-left t-3 theme-dark"
					>
						<i class="fas fa-plus" aria-hidden="true"></i>
					</a>';		
				$html .='			
			</div>
			';
			return $html;
		}
		else
			return false;
	}
	
	
	public static function addEditLessonArea($idItem,$section=false)
	{
		global $USER;
		if(Property::getInstance()->get(SF_SITE_DIR, "lesson_edit_mode") == "Y"&& $USER->IsAuthorized())
		{
			\Bitrix\Main\Loader::includeSharewareModule("iblock");
			
			$resItem = \CIBlockElement::GetByID($idItem);
			if($arItem = $resItem->Fetch())
				$idIblock = $arItem["IBLOCK_ID"];
			
			$resIblock = \CIBlock::GetByID($idIblock);
			if($arIblock = $resIblock->Fetch())
				$typeIblock = $arIblock["IBLOCK_TYPE_ID"];
			
			
			$html = '
			<div data-iblock-edit-item data-item-id = '.$idItem.' class="position-absolute w-100 h-100"  style="top:0; left:0; z-index: 120">
				<div class="position-relative w-100 h-100 sf-viewbox-wrap">
					<div class="sf-viewbox sf-viewbox-hover bg-white b-theme-100 b-1 transition"></div>
					<div class="sf-viewbox sf-viewbox-hover theme-light bg-transparent">
						<div class="t-center align-middle">
							<div class="btn-group">';
								$html .='
								<a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-content-modifier="p-0 h-100" 
									sf-modal-modifier = "fixed-right w-md-80" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.lesson.edit.php?iblock='.$idIblock.'&section='.$section.'" 
									sf-close-modifier="sf-close-left t-3 theme-dark"
								>
									<i class="fas fa-plus" aria-hidden="true"></i>
								</a>
							    <a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-content-modifier="p-0 h-100" 
									sf-modal-modifier = "fixed-right w-md-80" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.lesson.edit.php?iblock='.$idIblock.'&id='.$idItem.'" 
									sf-close-modifier="sf-close-left t-3 theme-dark"
								>
									<i class="fas fa-pen" aria-hidden="true"></i>
								</a>
								<a 
									class="btn btn-primary btn-outline btn-icon btn-1" 
									href="#" 
									sf-modal 
									sf-modal-modifier="w-20" 
									sf-src="'.SF_DATA_DIR.'/admin/iblock.lesson.delete.php?id='.$idItem.'" 
								>
									<i class="fas fa-trash" aria-hidden="true"></i>
								</a>';
							
							$html .='
							</div>
						</div>
					</div>
				</div>
			</div>
			';
			return $html;
		}
		else
			return false;
	}
	
}
?>