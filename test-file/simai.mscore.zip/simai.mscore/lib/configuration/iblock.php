<?
namespace SIMAI\Main\Configuration;



class Iblock
{
	private static $instance;
	private $storedData = null;
	private $data = array();
	const SESSION_PROPERTY_NAME = 'iblock_property';

	public static function getValue($name)
	{
		$configuration = self::getInstance();
		if($configuration->get($name) != null) 
			return $configuration->get($name);
		else {
			$id = self::getIblockID($name);
			if(isset($id)){
				self::setValue($name, $id);
				return $id;
			}
		}
	}

	public static function setValue($name, $value)
	{
		$configuration = self::getInstance();
		$configuration->add($name, $value);
		$configuration->saveConfiguration();
	}

	private function __construct()
	{
		
	}

	public static function getInstance()
	{
		if (!isset(self::$instance))
		{
			$c = __CLASS__;
			self::$instance = new $c;
		}

		return self::$instance;
	}

	private function loadConfiguration()
	{
		$this->isLoaded = false;

		if (isset($_SESSION[self::SESSION_PROPERTY_NAME]))
		{
			$dataTmp = $_SESSION[self::SESSION_PROPERTY_NAME];
			if(is_array($dataTmp))
			{
				$this->data = $dataTmp;
			}
		}
		
		$this->isLoaded = true;
	}
	
	public function saveConfiguration()
	{
		if (!$this->isLoaded)
			$this->loadConfiguration();

		$data = ($this->storedData !== null) ? $this->storedData : $this->data;
		
		if(!self::is_session_started()) session_start();
		
		$_SESSION[self::SESSION_PROPERTY_NAME] = $data;
	}
	
	public function add($name, $value)
	{
		if (!$this->isLoaded)
			$this->loadConfiguration();

			$this->data[$name] = $value;
	}

	public function delete($name)
	{
		if (!$this->isLoaded)
			$this->loadConfiguration();

		if (isset($this->data[$name])) unset($this->data[$name]);
	}

	public function get($name)
	{
		if (!$this->isLoaded)
			$this->loadConfiguration();

		if (isset($this->data[$name]))
			return $this->data[$name];

		return null;
	}
	
	static function is_session_started()
	{
	  if (version_compare(phpversion(), '5.4.0', '>=') ) {
            return session_status() === PHP_SESSION_ACTIVE ? TRUE : FALSE;
        } else {
            return session_id() === '' ? FALSE : TRUE;
        }
	}	
	
	function getIblockID($name){
		if(\CModule::IncludeModule("iblock")){
			$res = \CIBlock::GetList(
				Array(), 
				Array(
					'CODE'=>$name, 
				), true
			);
			$ar_res = $res->Fetch();
			return $ar_res['ID'];
		}
	}
}
