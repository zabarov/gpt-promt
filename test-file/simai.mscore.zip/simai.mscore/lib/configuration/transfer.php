<?
namespace SIMAI\Main\Configuration;

class Transfer
{
	/**
	 * @var Configuration
	 */
	private static $instance;
	private $data = array();


	public static function getValue($name)
	{
		$configuration = Transfer::getInstance();
		return $configuration->get($name);
	}

	public static function setValue($name, $value)
	{
		$configuration = Transfer::getInstance();
		$configuration->add($name, $value);
	}

	private function __construct()
	{
		
	}

	/**
	 * @static
	 * @return Transfer
	 */
	public static function getInstance()
	{
		if (!isset(self::$instance))
		{
			$c = __CLASS__;
			self::$instance = new $c;
		}

		return self::$instance;
	}

	public function add($name, $value)
	{
		$configuration = Transfer::getInstance();
		
		if (!isset($configuration->data[$name]))
			$configuration->data[$name] = array("value" => $value);
		else
			$configuration->data[$name] = array("value" => $value);
	}

	public function delete($name)
	{
		$configuration = Transfer::getInstance();
		
		if (isset($configuration->data[$name]))
			unset($configuration->data[$name]);
	}

	public function get($name)
	{
		$configuration = Transfer::getInstance();
		if (isset($configuration->data[$name]))
			return $configuration->data[$name]["value"];

		return null;
	}	
}
