<?
//only portal
namespace SIMAI\Disk;

	class Disk{  
	  
	   //id задачи  статус XML
	   static function add($fields)
	   {
		   \Bitrix\Main\Loader::includeModule("highloadblock");

		   $arHlData = \Bitrix\Highloadblock\HighloadBlockTable::getList(array('select' => array("ID", "NAME"), 'filter' => array("NAME" => "SFFile")));
		
		   if($arHlbk = $arHlData->Fetch()) { 
				$hlbl = $arHlbk['ID'];
		   }
		   
		   if(!isset($fields["MEDIA"])){
			   	$fields["MEDIA"] = 0;
		   }
		   if(!isset($fields["MEDIA_COLLECTION"])){
			   	$fields["MEDIA_COLLECTION"] = "";
		   }
		   if(!isset($fields["CIBLOCKELEMENT"])){
			   	$fields["CIBLOCKELEMENT"] = "";
		   }
		   

            //add
			$hlblock = \Bitrix\Highloadblock\HighloadBlockTable::getById($hlbl)->fetch(); 
			$entity = \Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock); 
			$entity_data_class = $entity->getDataClass(); 
			
			
			$rsData = $entity_data_class::getList(array(
				"select" => array("*"),
				"order" => array("ID" => "ASC"),
				"filter" => array("UF_SFFILE_ID" => $fields["ID"])  // Задаем параметры фильтра выборки
			 ));
			 
			 if(!$rsData->Fetch()){

				$data = array(
					"UF_SFFILE_ID" => $fields["ID"],
					"UF_SFFILE_SITE" => $fields["SITE"],
					"UF_SFFILE_SIZE" => $fields["SIZE"],
					"UF_SFFILE_LINK" => $fields["LINK"],
					"UF_SFFILE_MEDIA" => $fields["MEDIA"],
					"UF_SFFILE_CIBLOCKELEMENT" => $fields["CIBLOCKELEMENT"],
					"UF_SFFILE_MEDIA_COLLECTION" => $fields["MEDIA_COLLECTION"]
				 );
			  
				 $result = $entity_data_class::add($data);
			 }
		}

		static function delete($idFile)
		{

		   \Bitrix\Main\Loader::includeModule("highloadblock");
		   $arHlData = \Bitrix\Highloadblock\HighloadBlockTable::getList(array('select' => array("ID", "NAME"), 'filter' => array("NAME" => "SFFile")));
		
		   if($arHlbk = $arHlData->Fetch()) { 
				$hlbl = $arHlbk['ID'];
		   }

            //delete
			$hlblock = \Bitrix\Highloadblock\HighloadBlockTable::getById($hlbl)->fetch(); 
			$entity = \Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock); 
			$entity_data_class = $entity->getDataClass(); 


			$rsData = $entity_data_class::getList(array(
				"select" => array("*"),
				"order" => array("ID" => "ASC"),
				"filter" => array("UF_SFFILE_ID" => $idFile)  // Задаем параметры фильтра выборки
			 ));
			 
			 if($arData = $rsData->Fetch()){
				$entity_data_class::Delete($arData["ID"]);
			 }
		}

		static function get($idOrg)
		{
			/*\Bitrix\Main\Loader::includeModule("highloadblock");

		    $arHlData = \Bitrix\Highloadblock\HighloadBlockTable::getList(array('select' => array("ID", "NAME"), 'filter' => array("NAME" => "SFFile")));
		    if($arHlbk = $arHlData->Fetch()) { 
				$hlbl = $arHlbk['ID'];
		    }

			//set data
			$hlblock = \Bitrix\Highloadblock\HighloadBlockTable::getById($hlbl)->fetch(); 
			$entity = \Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock); 
			$entity_data_class = $entity->getDataClass(); 

			$rsData = $entity_data_class::getList(array(
				"select" => array("*"),
				"order" => array("ID" => "ASC"),
				"filter" => array("UF_DISK__ORG" => $idOrg)  
			));
			
			if($arData = $rsData->Fetch()){
               return $arData;
			}else{
				//добавляем пустой
				$data = array(
					"UF_DISK__SIZE" => 0,
					"UF_DISK__ORG"=> $idOrg,
					"UF_DISK__COUNT_FILE" => 0
				); 
				$result = $entity_data_class::add($data);
				$data["ID"] = $result->getId();
				return $data;
			}
			*/
		}
		
		static function getById($id)
		{
			\Bitrix\Main\Loader::includeModule("highloadblock");

		    $arHlData = \Bitrix\Highloadblock\HighloadBlockTable::getList(array('select' => array("ID", "NAME"), 'filter' => array("NAME" => "SFFile")));
		    if($arHlbk = $arHlData->Fetch()) { 
				$hlbl = $arHlbk['ID'];
		    }

			//set data
			$hlblock = \Bitrix\Highloadblock\HighloadBlockTable::getById($hlbl)->fetch(); 
			$entity = \Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock); 
			$entity_data_class = $entity->getDataClass(); 

			$rsData = $entity_data_class::getList(array(
				"select" => array("*"),
				"order" => array("ID" => "ASC"),
				"filter" => array("ID" => $id)  
			));
			
			if($arData = $rsData->Fetch()){
               return $arData;
			}
			
			return false;
		}

	}
		
		
		
	